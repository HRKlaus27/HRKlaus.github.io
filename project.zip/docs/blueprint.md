# **App Name**: MonsterFlow Office

## Core Features:

- Animated Mascot Authentication: A split-screen login featuring a 3D monster that tracks cursor movements, reacts to password focus by covering eyes, and performs a wave animation on exit.
- Glassmorphism Command Center: A dashboard redesign using translucent, blurred layers, soft shadows, and rounded geometric cards for all management modules.
- Ambient Visual Layer: Background featuring soft cloud gradients and interactive floating particles that respond to navigation transitions.
- Animated Analytics Facelift: Redesigned KPI cards and progress widgets with Framer Motion entry effects and custom-styled modern charting interfaces.
- Collapsible Dynamic Sidebar: A premium navigation menu with spring-based hover effects and smooth layout shifts for better information density.
- Responsive Dual-Theme Engine: A seamless light/dark mode implementation with optimized layouts for mobile, tablet, and high-fidelity desktop displays.
- AI Insight Summary Tool: An AI tool that reasons through existing sales and inventory data to provide a short, natural language summary of the day's KPIs in a greeting card.

## Style Guidelines:

- Primary Color: Vibrant Amethyst (#AB86E8) representing the creative and playful energy of the brand mascot.
- Background: Soft Cloud Lilac (#F9F7FA), a desaturated variant that maintains visual harmony in the light theme.
- Accent: Deep Slate Indigo (#44449D), used for contrast in critical call-to-actions and interactive elements.
- Font pairing: 'Space Grotesk' for bold, modern headlines and 'Inter' for readable, high-performance body text and data points.
- Modern duotone icons with rounded corners, utilizing subtle gradients and semi-transparent accents to match the Glassmorphism aesthetic.
- Spacious card-based layout with excessive padding, soft 24px corner rounding, and wide-gutter grid systems.
- Framer Motion orchestrated transitions: spring-based page entries, layout-id card expansions, and skeleton loading states.