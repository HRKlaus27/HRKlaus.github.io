
import { config } from 'dotenv';
config();

import '@/ai/flows/daily-kpi-summary.ts';
import '@/ai/flows/security-voice-flow.ts';
