'use server';
/**
 * @fileOverview A Genkit flow that generates a natural language summary of daily sales and inventory KPIs.
 *
 * - dailyKpiSummary - A function that handles the generation of the KPI summary greeting card.
 * - DailyKpiSummaryInput - The input type for the dailyKpiSummary function.
 * - DailyKpiSummaryOutput - The return type for the dailyKpiSummary function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SalesRecordSchema = z.object({
  product: z.string().describe('The name of the product sold.'),
  quantity: z.number().int().positive().describe('The quantity of the product sold.'),
  price: z.number().positive().describe('The price per unit of the product.'),
  timestamp: z.string().datetime().describe('The ISO 8601 timestamp of the sale.'),
});

const InventoryRecordSchema = z.object({
  product: z.string().describe('The name of the product.'),
  stockLevel: z.number().int().min(0).describe('The current stock level of the product.'),
  lastUpdated: z.string().datetime().describe('The ISO 8601 timestamp when the stock level was last updated.'),
});

const DailyKpiSummaryInputSchema = z.object({
  currentDate: z.string().describe('The current date in a human-readable format (e.g., "Monday, October 26, 2023").'),
  salesData: z.array(SalesRecordSchema).describe('An array of daily sales records.'),
  inventoryData: z.array(InventoryRecordSchema).describe('An array of daily inventory records.'),
});
export type DailyKpiSummaryInput = z.infer<typeof DailyKpiSummaryInputSchema>;

const DailyKpiSummaryOutputSchema = z.object({
  greeting: z.string().describe('A friendly greeting for the business owner.'),
  summary: z.string().describe('A natural language summary of the day’s key sales and inventory performance indicators.'),
  actionableInsights: z.array(z.string()).optional().describe('Optional actionable insights based on the KPI summary.'),
});
export type DailyKpiSummaryOutput = z.infer<typeof DailyKpiSummaryOutputSchema>;

export async function dailyKpiSummary(input: DailyKpiSummaryInput): Promise<DailyKpiSummaryOutput> {
  try {
    return await dailyKpiSummaryFlow(input);
  } catch (error: any) {
    // Handle Quota Exhausted (429) or other API errors gracefully
    if (error.message?.includes('429') || error.message?.includes('RESOURCE_EXHAUSTED')) {
      return {
        greeting: "Hello Admin",
        summary: "Our AI analyst is currently taking a quick breather due to high demand. Your business metrics are being tracked, and a fresh AI summary will be available in a few moments.",
        actionableInsights: ["System is currently processing high volumes of data.", "Check back shortly for updated AI insights."]
      };
    }
    return {
      greeting: "Hello Admin",
      summary: "We're having a slight hiccup generating your AI summary right now, but your dashboard below is fully up to date with the latest transactions.",
      actionableInsights: ["Manual review of recent transactions recommended."]
    };
  }
}

const prompt = ai.definePrompt({
  name: 'dailyKpiSummaryPrompt',
  input: { schema: DailyKpiSummaryInputSchema },
  output: { schema: DailyKpiSummaryOutputSchema },
  prompt: `You are an AI assistant for a business owner, providing a daily summary of key performance indicators (KPIs).
Your goal is to present a friendly, natural language summary within a greeting card format.
Analyze the provided sales and inventory data for today, {{{currentDate}}}, and highlight the most important insights.

Sales Data:
{{#each salesData}}
  - Product: {{{this.product}}}, Quantity: {{{this.quantity}}}, Price: {{{this.price}}}, Timestamp: {{{this.timestamp}}}
{{/each}}
{{#unless salesData}}
  No sales data available for today.
{{/unless}}

Inventory Data:
{{#each inventoryData}}
  - Product: {{{this.product}}}, Stock Level: {{{this.stockLevel}}}, Last Updated: {{{this.lastUpdated}}}
{{/each}}
{{#unless inventoryData}}
  No inventory data available for today.
{{/unless}}

Based on the above data, generate a greeting and a concise summary for today's KPIs. Also, provide any actionable insights if applicable.
Your response should be in the JSON format as described by the output schema.
`,
});

const dailyKpiSummaryFlow = ai.defineFlow(
  {
    name: 'dailyKpiSummaryFlow',
    inputSchema: DailyKpiSummaryInputSchema,
    outputSchema: DailyKpiSummaryOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
