'use server';
/**
 * @fileOverview A Genkit flow for generating a security alert AI voice.
 *
 * - generateSecurityWarning - A function that returns a data URI for the alert voice.
 */

import { ai } from '@/ai/genkit';
import { googleAI } from '@genkit-ai/google-genai';
import * as wav from 'wav';

export async function generateSecurityWarning(): Promise<string> {
  try {
    const { media } = await ai.generate({
      model: googleAI.model('gemini-2.5-flash-preview-tts'),
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            // "Algenib" is a high-quality female voice profile
            prebuiltVoiceConfig: { voiceName: 'Algenib' },
          },
        },
      },
      prompt: "System warning. You cannot enter here. Only admin can access here. Please proceed to main page. System warning. Please proceed to main page.",
    });

    if (!media) {
      throw new Error('no media returned');
    }

    const audioBuffer = Buffer.from(
      media.url.substring(media.url.indexOf(',') + 1),
      'base64'
    );

    return 'data:audio/wav;base64,' + (await toWav(audioBuffer));
  } catch (error) {
    console.error('TTS Generation failed:', error);
    throw error;
  }
}

async function toWav(
  pcmData: Buffer,
  channels = 1,
  rate = 24000,
  sampleWidth = 2
): Promise<string> {
  return new Promise((resolve, reject) => {
    const writer = new wav.Writer({
      channels,
      sampleRate: rate,
      bitDepth: sampleWidth * 8,
    });

    let bufs: Buffer[] = [];
    writer.on('error', reject);
    writer.on('data', function (d) {
      bufs.push(d);
    });
    writer.on('end', function () {
      resolve(Buffer.concat(bufs).toString('base64'));
    });

    writer.write(pcmData);
    writer.end();
  });
}
