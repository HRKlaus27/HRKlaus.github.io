'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { AuthLoadingScreen } from '@/components/AuthLoadingScreen';
import { ArrowLeft, Globe, Lock, ShieldCheck, Cpu, Terminal, Eye, ShieldAlert, Volume2 } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { CodeRainBackground } from '@/components/CodeRainBackground';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { generateSecurityWarning } from '@/ai/flows/security-voice-flow';

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [showWarning, setShowWarning] = useState(false);
  const [mounted, setMounted] = useState(false);
  
  const [uid, setUid] = useState('');
  const [key, setKey] = useState('');
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const redirectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const heroBg = PlaceHolderImages.find(img => img.id === 'cyber-ai-robot');
  const paperBg = PlaceHolderImages.find(img => img.id === 'bond-paper-stack');

  useEffect(() => {
    setMounted(true);
    return () => {
      window.speechSynthesis.cancel();
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        audioRef.current = null;
      }
      if (redirectTimeoutRef.current) {
        clearTimeout(redirectTimeoutRef.current);
      }
    };
  }, []);

  const playSecurityVoice = useCallback(async () => {
    const message = "System warning. You cannot enter here. Only admin can access here. Please proceed to main page. System warning. Please proceed to main page.";
    window.speechSynthesis.cancel();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }

    try {
      const audioUri = await generateSecurityWarning();
      window.speechSynthesis.cancel(); 
      const audio = new Audio(audioUri);
      audioRef.current = audio;
      audio.play().catch(e => {
        console.warn("Audio play interrupted or failed:", e);
      });
    } catch (e) {
      console.warn("Genkit AI Voice failed, using browser fallback synthesis.");
      const utterance = new SpeechSynthesisUtterance(message);
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(v => v.name.includes('Female') || v.name.includes('Girl') || v.name.includes('Google UK English Female') || v.name.includes('Algenib'));
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }
      utterance.rate = 0.95;
      utterance.pitch = 1.1;
      window.speechSynthesis.speak(utterance);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const MASTER_UID = "cyber_access26";
    const MASTER_KEY = "SKYNET_ACCESS_2026";

    if (uid === MASTER_UID && key === MASTER_KEY) {
      setIsLoggingIn(true);
      setShowWarning(false);
      window.speechSynthesis.cancel();
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (redirectTimeoutRef.current) {
        clearTimeout(redirectTimeoutRef.current);
      }
      
      setTimeout(() => {
        setShowLoader(true);
        setTimeout(() => {
          router.push('/dashboard');
        }, 3000);
      }, 1000);
    } else {
      setShowWarning(true);
      playSecurityVoice();
      toast({
        title: "ACCESS DENIED",
        description: "Intrusion detected. Security protocols activated. Ejection sequence started.",
        variant: "destructive",
      });

      if (redirectTimeoutRef.current) clearTimeout(redirectTimeoutRef.current);
      redirectTimeoutRef.current = setTimeout(() => {
        router.push('/');
      }, 11000);
    }
  };

  if (!mounted) return null;

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden font-body bg-black text-white">
      <AnimatePresence>
        {showLoader && <AuthLoadingScreen />}
      </AnimatePresence>

      <AnimatePresence>
        {showWarning && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
              backgroundColor: ["rgba(255, 0, 0, 0)", "rgba(255, 0, 0, 0.7)", "rgba(255, 0, 0, 0)"]
            }}
            exit={{ opacity: 0 }}
            transition={{ 
              duration: 0.2, 
              repeat: 55,
              ease: "linear"
            }}
            className="fixed inset-0 z-[100] pointer-events-none mix-blend-hard-light"
          />
        )}
      </AnimatePresence>

      <div className="fixed inset-0 z-0">
        <Image 
          src={heroBg?.imageUrl || "https://picsum.photos/seed/cyber-ai-robot/1920/1080"}
          alt="PROJECT SKYnet Identity Portal"
          fill
          className="object-cover opacity-60"
          priority
          data-ai-hint="cybernetic humanoid"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black via-black/90 to-primary/20" />
        <CodeRainBackground color="#00ffff" opacity={0.1} />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-10 left-10 z-20"
      >
        <Link href="/" className="group flex items-center gap-4 px-8 py-4 rounded-full bg-white/5 backdrop-blur-3xl border border-white/10 hover:border-primary/40 transition-all shadow-2xl">
          <ArrowLeft className="w-4 h-4 text-primary group-hover:-translate-x-1 transition-transform" />
          <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white">Back to Node</span>
        </Link>
      </motion.div>

      <div className="relative z-10 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-0 items-stretch px-6">
        <div className="hidden lg:flex flex-col relative overflow-hidden rounded-l-[48px] border border-white/10 bg-black/40 backdrop-blur-3xl">
          <Image 
            src={paperBg?.imageUrl || "https://picsum.photos/seed/paper-stack/1200/800"}
            alt="Paper Assets"
            fill
            className="object-cover opacity-20 grayscale"
            data-ai-hint="bond paper"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
          <div className="p-16 relative z-20 flex flex-col h-full justify-between">
            <div className="space-y-8">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-primary/20 border border-primary/40 rounded-xl flex items-center justify-center neon-glow">
                    <Cpu className="text-primary w-6 h-6" />
                 </div>
                 <span className="text-[10px] font-bold text-primary tracking-[0.5em] uppercase">Authorized Entity</span>
              </div>
              <h2 className="text-5xl font-headline font-bold text-white leading-[0.9] tracking-tighter holographic-text uppercase">
                Confidential <br /> Access <br /> Server.
              </h2>
            </div>
            
            <div className="space-y-6">
              <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl">
                 <div className="flex items-center gap-3 mb-2">
                    <Terminal className="w-4 h-4 text-primary" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">System Log</span>
                 </div>
                 <div className="space-y-1">
                  <p className="text-[10px] text-primary/80 font-mono tracking-tighter">SECURE_LINK: [ESTABLISHED]</p>
                  <p className="text-[10px] text-white/40 font-mono tracking-tighter">ID_PROTOCOL: [PENDING]</p>
                 </div>
              </div>
              <p className="text-sm text-white/40 font-medium max-w-xs leading-relaxed">
                Connect your identity matrix to access the global network.
              </p>
            </div>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className={`w-full bg-black/60 backdrop-blur-3xl lg:rounded-r-[48px] rounded-[48px] lg:rounded-l-none border border-white/10 p-16 md:p-20 flex flex-col justify-center space-y-12 shadow-2xl relative transition-all duration-300 ${showWarning ? 'border-red-500/50 shadow-[0_0_80px_rgba(255,0,0,0.5)]' : ''}`}
        >
          <div className="absolute top-10 right-10 flex items-center gap-2">
             <div className={`w-2 h-2 rounded-full ${showWarning ? 'bg-red-500 animate-ping' : 'bg-primary animate-ping'}`} />
             <span className={`text-[9px] font-bold uppercase tracking-widest ${showWarning ? 'text-red-500' : 'text-primary/60'}`}>
               {showWarning ? 'BREACH ALERT' : 'Hub Sync v4.2'}
             </span>
          </div>

          <div className="space-y-4">
            <h1 className={`text-5xl font-headline font-bold tracking-tighter uppercase ${showWarning ? 'text-red-500 animate-pulse' : 'holographic-text'}`}>
              ADMIN ACCESS.
            </h1>
            <p className="text-[10px] font-bold uppercase tracking-[0.6em] text-white/30">Cyber Security Log In Access</p>
          </div>

          <AnimatePresence>
            {showWarning && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: -20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -20 }}
                className="w-full"
              >
                <Alert variant="destructive" className="bg-red-500/20 border-red-500/50 rounded-2xl p-6 backdrop-blur-xl animate-pulse ring-2 ring-red-500/20 shadow-[0_0_30px_rgba(255,0,0,0.3)]">
                  <ShieldAlert className="h-6 w-6 text-red-500" />
                  <AlertTitle className="text-sm font-bold uppercase tracking-[0.2em] mb-2 text-red-500 flex items-center gap-2">
                    <Volume2 className="w-4 h-4 animate-bounce" /> Security Breach Detected
                  </AlertTitle>
                  <AlertDescription className="text-[11px] font-bold uppercase tracking-widest text-white leading-relaxed">
                    Breach Protocol Initialized. System Alert Active. <br />
                    <span className="flex items-center gap-2 mt-3 text-red-400 font-bold">
                      <Eye className="w-4 h-4 text-red-500 animate-pulse" /> ADMIN IS WATCHING.
                    </span>
                    <p className="mt-2 text-[10px] text-red-300 font-bold uppercase tracking-widest italic">User ejection in progress...</p>
                  </AlertDescription>
                </Alert>
              </motion.div>
            )}
          </AnimatePresence>

          <form onSubmit={handleLogin} className="space-y-10">
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[9px] font-bold uppercase tracking-[0.4em] text-white/40 ml-6">Admin UID</label>
                <div className="relative group">
                  <Globe className={`absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${showWarning ? 'text-red-500' : 'text-white/20 group-focus-within:text-primary'}`} />
                  <Input 
                    placeholder="Enter Admin UID"
                    value={uid}
                    onChange={(e) => setUid(e.target.value)}
                    className={`h-16 bg-white/5 border-white/10 rounded-2xl px-14 text-white focus:border-primary/40 transition-all placeholder:text-white/10 text-sm font-medium ${showWarning ? 'border-red-500 focus:border-red-500' : ''}`}
                    required
                    disabled={showWarning}
                  />
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-[9px] font-bold uppercase tracking-[0.4em] text-white/40 ml-6">Neural Access Key</label>
                <div className="relative group">
                  <Lock className={`absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${showWarning ? 'text-red-500' : 'text-white/20 group-focus-within:text-primary'}`} />
                  <Input 
                    type="password"
                    placeholder="••••••••"
                    value={key}
                    onChange={(e) => setKey(e.target.value)}
                    className={`h-16 bg-white/5 border-white/10 rounded-2xl px-14 text-white focus:border-primary/40 transition-all placeholder:text-white/10 text-sm font-medium ${showWarning ? 'border-red-500 focus:border-red-500' : ''}`}
                    required
                    disabled={showWarning}
                  />
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              disabled={isLoggingIn || showWarning}
              className={`w-full h-16 font-bold rounded-2xl text-xs shadow-2xl transition-all active:scale-[0.98] uppercase tracking-[0.4em] ${showWarning ? 'bg-red-600 hover:bg-red-700 text-white cursor-not-allowed' : 'bg-white hover:bg-primary text-black hover:text-white'}`}
            >
              {isLoggingIn ? "Authenticating..." : showWarning ? "SYSTEM LOCKED" : "Authorize Access"}
            </Button>

            <div className="flex items-center justify-center gap-4 pt-4 opacity-40">
               <ShieldCheck className={`w-5 h-5 ${showWarning ? 'text-red-500' : 'text-primary'}`} />
               <span className="text-[10px] text-white uppercase tracking-[0.5em] font-bold">Network Secured</span>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}