
'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { 
  ArrowRight,
  Globe,
  Zap,
  ShieldCheck,
  Cpu,
  Mail,
  Send,
  User,
  MessageSquare
} from 'lucide-react';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Link from 'next/link';
import { CodeRainBackground } from '@/components/CodeRainBackground';

export default function LandingPage() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const heroBg = PlaceHolderImages.find(img => img.id === 'cyber-ai-robot');
  const docsImg = PlaceHolderImages.find(img => img.id === 'documents-stack');

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Protocol Transmitted",
        description: "Your inquiry has been successfully sent to the SKYnet Hub.",
      });
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen relative font-body selection:bg-primary/30 overflow-x-hidden bg-black text-white">
      {/* Cinematic Cyber Backdrop - AI Humanoid Robot */}
      <div className="fixed inset-0 z-0">
        <Image 
          src={heroBg?.imageUrl || "https://picsum.photos/seed/cyber-ai-robot/1920/1080"}
          alt="PROJECT SKYnet Neural Interface"
          fill
          className="object-cover opacity-70 transition-opacity duration-1000"
          priority
          data-ai-hint="cybernetic humanoid"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/80 to-black" />
        <CodeRainBackground color="#00ffff" opacity={0.15} />
      </div>

      {/* Floating Holographic Navbar */}
      <nav className="fixed top-8 w-full z-50 px-6">
        <div className="max-w-fit mx-auto rounded-full h-14 flex items-center px-8 gap-10 bg-white/5 backdrop-blur-3xl border border-white/10 shadow-[0_0_30px_rgba(0,255,255,0.1)]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary/20 border border-primary/40 rounded-lg flex items-center justify-center neon-glow">
              <Cpu className="text-primary w-4 h-4" />
            </div>
            <span className="font-headline font-bold text-lg text-white tracking-widest holographic-text">PROJECT SKYnet</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-[10px] font-bold text-white/60 uppercase tracking-[0.3em]">
            <button onClick={() => scrollToSection('home')} className="hover:text-primary transition-colors">Home</button>
            <button onClick={() => scrollToSection('services')} className="hover:text-primary transition-colors">Matrix</button>
            <button onClick={() => scrollToSection('about')} className="hover:text-primary transition-colors">Network</button>
            <button onClick={() => scrollToSection('contact')} className="hover:text-primary transition-colors">Connect</button>
          </div>
          <Link href="/login">
            <Button className="bg-primary hover:bg-primary/80 text-white rounded-full h-9 px-6 text-[10px] font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(177,134,232,0.4)]">
              Log in as Admin
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-primary/10 backdrop-blur-md px-6 py-2 rounded-full border border-primary/30 mb-10 shadow-[0_0_20px_rgba(177,134,232,0.2)]"
        >
          <span className="text-[9px] font-bold text-primary uppercase tracking-[0.5em] flex items-center gap-2">
            <Zap className="w-3 h-3 animate-pulse" /> Neural Print Protocol v4.2
          </span>
        </motion.div>

        <div className="max-w-5xl text-center space-y-8 relative z-10">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-9xl font-headline font-bold text-white leading-[0.9] tracking-tighter holographic-text"
          >
            Digital <br /> Perfection.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto font-medium leading-relaxed"
          >
            Powering your academic and professional workflow with futuristic <br />
            document solutions and neural-precision printing.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="pt-10 flex items-center justify-center gap-6"
          >
            <Button 
              onClick={() => scrollToSection('contact')}
              className="h-16 px-12 rounded-2xl bg-white text-black hover:bg-primary hover:text-white shadow-2xl font-bold text-sm uppercase tracking-widest transition-all duration-500"
            >
              Start Uplink <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <button className="text-[10px] font-bold text-white/40 hover:text-white flex items-center gap-3 uppercase tracking-widest transition-colors">
              <Globe className="w-5 h-5 text-primary" /> View Network Nodes
            </button>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="relative py-32 px-6 border-y border-white/5 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto space-y-24">
          <div className="text-center space-y-4">
             <div className="w-1.5 h-1.5 bg-primary rounded-full mx-auto animate-ping" />
            <h2 className="text-5xl font-headline font-bold text-white tracking-tight holographic-text">System Modules</h2>
            <p className="text-[10px] font-bold text-primary uppercase tracking-[0.4em]">High-Efficiency Document Processing</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <ServiceCard 
              icon={<Zap className="w-8 h-8" />}
              title="Quantum Print"
              description="High-definition document transmission and physical manifesting at neural speed."
            />
            <ServiceCard 
              icon={<ShieldCheck className="w-8 h-8" />}
              title="Secure Binding"
              description="Cyber-grade hardbound and softbound encapsulation for your critical assets."
            />
            <ServiceCard 
              icon={<Globe className="w-8 h-8" />}
              title="Global Supply"
              description="Sourcing premium materials across the network for your local workspace."
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="relative py-32 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="space-y-10">
            <div className="space-y-4">
               <span className="text-[10px] font-bold text-primary uppercase tracking-[0.5em]">Identity Protocol</span>
               <h3 className="text-6xl font-headline font-bold text-white leading-[1] tracking-tighter holographic-text">The Neural Edge <br /> in Printing.</h3>
            </div>
            <p className="text-xl text-white/50 leading-relaxed font-medium">
              PROJECT SKYnet is more than just a shop—it's an infrastructure for creators. We bridge the gap between digital vision and physical reality.
            </p>
            <div className="flex gap-16">
              <div>
                <p className="text-5xl font-headline font-bold text-white">100%</p>
                <p className="text-[9px] font-bold text-primary uppercase tracking-[0.3em] mt-2">Network Uptime</p>
              </div>
              <div>
                <p className="text-5xl font-headline font-bold text-white">4.2ms</p>
                <p className="text-[9px] font-bold text-primary uppercase tracking-[0.3em] mt-2">Response Latency</p>
              </div>
            </div>
          </div>
          <div className="relative aspect-square rounded-[48px] overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] group">
            <Image 
              src={docsImg?.imageUrl || "https://picsum.photos/seed/office-docs/1200/800"}
              alt="System Assets"
              fill
              className="object-cover transition-all duration-700 opacity-60 group-hover:opacity-100"
              data-ai-hint="documents stack"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            <div className="absolute bottom-8 left-8 flex items-center gap-3">
               <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
               <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Verified Local Node: Dipolog</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative py-32 px-6">
        <div className="max-w-4xl mx-auto bg-black/60 backdrop-blur-3xl rounded-[48px] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col">
          <div className="bg-white/5 px-10 py-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-headline font-bold text-white tracking-widest uppercase holographic-text">Initialize Uplink</h3>
            </div>
            <span className="text-[9px] font-bold text-primary uppercase tracking-0.4em">Transmit project specifications</span>
          </div>

          <form onSubmit={handleContactSubmit} className="p-10 md:p-16 space-y-10">
            <div className="space-y-8">
              <div className="flex flex-col md:flex-row md:items-center gap-4 border-b border-white/5 pb-4 group">
                <div className="w-full md:w-48 flex items-center gap-2">
                  <User className="w-4 h-4 text-white/20 group-focus-within:text-primary transition-colors" />
                  <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Entity Name</Label>
                </div>
                <Input 
                  placeholder="DESIGNER_ALPHA" 
                  required 
                  className="flex-1 bg-transparent border-none text-white placeholder:text-white/10 focus-visible:ring-0 px-0 h-10 text-sm font-medium" 
                />
              </div>

              <div className="flex flex-col md:flex-row md:items-center gap-4 border-b border-white/5 pb-4 group">
                <div className="w-full md:w-48 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-white/20 group-focus-within:text-primary transition-colors" />
                  <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Gmail Account</Label>
                </div>
                <Input 
                  placeholder="USER@DOMAIN.NET" 
                  type="email" 
                  required 
                  className="flex-1 bg-transparent border-none text-white placeholder:text-white/10 focus-visible:ring-0 px-0 h-10 text-sm font-medium" 
                />
              </div>

              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="w-4 h-4 text-white/20" />
                  <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest">Packet Payload (Inquiry)</Label>
                </div>
                <Textarea 
                  placeholder="Define your document requirements..." 
                  required 
                  className="min-h-[220px] rounded-3xl bg-white/5 border-white/10 px-8 py-8 focus:ring-primary text-white placeholder:text-white/10 leading-relaxed text-sm resize-none" 
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-6">
              <div className="hidden md:flex items-center gap-3 opacity-30">
                <ShieldCheck className="w-4 h-4 text-primary" />
                <span className="text-[8px] font-bold uppercase tracking-widest text-white">Encrypted Transmission</span>
              </div>
              <Button 
                type="submit" 
                disabled={isSubmitting} 
                className="h-16 px-12 bg-white text-black hover:bg-primary hover:text-white font-bold rounded-2xl transition-all shadow-[0_0_30px_rgba(255,255,255,0.1)] uppercase tracking-0.4em text-[11px] flex items-center gap-3"
              >
                {isSubmitting ? "Transmitting..." : (
                  <>
                    Send Data Packet
                    <Send className="w-4 h-4" />
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </section>

      <footer className="relative py-24 border-t border-white/5 text-center space-y-10">
          <div className="flex items-center justify-center gap-4">
            <div className="w-8 h-8 bg-primary/20 border border-primary/40 rounded-lg flex items-center justify-center neon-glow">
              <Cpu className="text-primary w-4 h-4" />
            </div>
            <span className="font-headline font-bold text-2xl text-white tracking-widest holographic-text">PROJECT SKYnet</span>
          </div>
          <div className="space-y-3">
            <p className="text-[10px] font-bold text-white/20 uppercase tracking-0.6em">
              © 2024 PROJECT SKYnet Technologies • Global Node Access
            </p>
            <div className="flex justify-center gap-6 opacity-40">
               <span className="text-[9px] font-bold uppercase tracking-widest">v4.2.0</span>
               <span className="text-[9px] font-bold uppercase tracking-widest">SECURE_LINK_ENCRYPTED</span>
            </div>
          </div>
      </footer>
    </div>
  );
}

function ServiceCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-14 rounded-[56px] bg-white/[0.03] border border-white/10 hover:border-primary/40 transition-all group hover:bg-white/[0.05] duration-500 relative overflow-hidden">
      <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-primary/5 blur-[60px] rounded-full group-hover:bg-primary/20 transition-all duration-700" />
      <div className="w-16 h-16 bg-primary/10 border border-primary/20 rounded-2xl flex items-center justify-center text-primary shadow-lg mb-10 group-hover:scale-110 transition-transform duration-500">
        {icon}
      </div>
      <div className="space-y-6">
        <h3 className="text-2xl font-headline font-bold text-white tracking-tight uppercase holographic-text">{title}</h3>
        <p className="text-white/40 leading-relaxed font-medium text-sm">{description}</p>
      </div>
    </div>
  );
}
