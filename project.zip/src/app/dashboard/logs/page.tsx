
'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { History } from 'lucide-react';

export default function LogsPage() {
  return (
    <div className="space-y-6">
      <Card className="glass-panel border-none">
        <CardHeader className="flex flex-row items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
            <History className="text-primary w-6 h-6" />
          </div>
          <div>
            <CardTitle className="text-2xl font-headline font-bold">Activity Logs</CardTitle>
            <p className="text-sm text-muted-foreground">Audit trail of all system activities.</p>
          </div>
        </CardHeader>
        <CardContent className="p-8 flex flex-col items-center justify-center min-h-[400px] border-2 border-dashed border-primary/20 rounded-3xl mt-4">
          <p className="text-accent font-medium italic">Activity Logs Module is under development...</p>
        </CardContent>
      </Card>
    </div>
  );
}
