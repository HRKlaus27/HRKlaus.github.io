'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { SidebarProvider, Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarGroup, SidebarGroupLabel, SidebarGroupContent, SidebarTrigger, SidebarInset } from '@/components/ui/sidebar';
import { LayoutDashboard, LogOut, Receipt, Package, Boxes, Cpu, BarChart3, Wallet, Camera, Mail, Send, Save, X, ZoomIn, ZoomOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { CodeRainBackground } from '@/components/CodeRainBackground';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Cropper, { Area } from 'react-easy-crop';
import { initializeFirebase, useDoc } from '@/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { db } = initializeFirebase();
  const { toast } = useToast();
  const heroBg = PlaceHolderImages.find(img => img.id === 'cyber-ai-robot');
  
  const [mounted, setMounted] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // Profile State
  const [userName, setUserName] = useState('Core Admin');
  const [avatar, setAvatar] = useState('https://picsum.photos/seed/ai-avatar/100');
  const [tempName, setTempName] = useState(userName);
  
  // Cropper State
  const [image, setImage] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(null);
  const [showCropper, setShowCropper] = useState(false);

  // Persistence Hook
  const userProfileRef = React.useMemo(() => db ? doc(db, 'system_config', 'profile') : null, [db]);
  const { data: profileData } = useDoc(userProfileRef);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (profileData) {
      setUserName(profileData.name || 'Core Admin');
      setAvatar(profileData.avatar || 'https://picsum.photos/seed/ai-avatar/100');
      setTempName(profileData.name || 'Core Admin');
    }
  }, [profileData]);

  const onCropComplete = useCallback((_croppedArea: Area, croppedAreaPixels: Area) => {
    setCroppedAreaPixels(croppedAreaPixels);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setImage(reader.result as string);
        setShowCropper(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const createCroppedImage = async (imageSrc: string, pixelCrop: Area): Promise<string> => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new window.Image();
    img.src = imageSrc;

    return new Promise((resolve, reject) => {
      img.onload = () => {
        canvas.width = 300;
        canvas.height = 300;
        if (!ctx) return reject();
        ctx.drawImage(
          img,
          pixelCrop.x,
          pixelCrop.y,
          pixelCrop.width,
          pixelCrop.height,
          0,
          0,
          300,
          300
        );
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = reject;
    });
  };

  const handleSaveCrop = async () => {
    if (image && croppedAreaPixels) {
      try {
        const croppedImg = await createCroppedImage(image, croppedAreaPixels);
        setAvatar(croppedImg);
        setShowCropper(false);
        setImage(null);
        toast({ title: "Visual Packet Updated", description: "Identity manifestation refreshed." });
      } catch (e) {
        toast({ title: "Capture Error", description: "Failed to process visual data.", variant: "destructive" });
      }
    }
  };

  const handleSaveChanges = async () => {
    if (!db) return;
    try {
      await setDoc(doc(db, 'system_config', 'profile'), {
        name: tempName,
        avatar: avatar,
        updatedAt: serverTimestamp()
      });
      setUserName(tempName);
      setIsEditing(false);
      toast({ title: "Protocol Committed", description: "Identity matrix synchronized with neural storage." });
    } catch (error: any) {
      toast({ title: "Sync Error", description: error.message, variant: "destructive" });
    }
  };

  const handleBind = (provider: string) => {
    toast({
      title: "Neural Link Established",
      description: `${provider} matrix successfully bound to your identity protocol.`,
    });
  };

  if (!mounted) return null;

  return (
    <SidebarProvider>
      <div className="flex h-screen w-full relative overflow-hidden bg-black text-white">
        <div className="absolute inset-0 z-0">
          <Image 
            src={heroBg?.imageUrl || "https://picsum.photos/seed/cyber-ai-robot/1920/1080"}
            alt="Dashboard Neural Interface"
            fill
            className="object-cover opacity-40 blur-[4px]"
            priority
            data-ai-hint="cybernetic humanoid"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-black via-black/80 to-primary/10" />
          <CodeRainBackground color="#00ffff" opacity={0.1} />
        </div>

        <div className="relative z-10 flex w-full h-full">
          <Sidebar collapsible="icon" className="border-r border-white/5 bg-black/40 backdrop-blur-3xl">
            <SidebarHeader className="h-24 flex items-center px-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary/20 border border-primary/40 rounded-2xl flex items-center justify-center neon-glow shrink-0">
                  <Cpu className="text-primary w-6 h-6" />
                </div>
                <div className="flex flex-col group-data-[collapsible=icon]:hidden">
                  <span className="font-headline font-bold text-xl holographic-text uppercase">SKYnet HUB</span>
                  <span className="text-[9px] font-bold text-primary/60 tracking-[0.3em] uppercase">Neural Hub</span>
                </div>
              </div>
            </SidebarHeader>
            <SidebarContent className="px-3">
              <SidebarGroup>
                <SidebarGroupLabel className="px-4 text-[10px] uppercase tracking-widest font-bold text-white/30">System Control</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard">
                          <LayoutDashboard className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">Command Center</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard/invoice'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard/invoice">
                          <Receipt className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">Neural Invoice</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard/reports'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard/reports">
                          <BarChart3 className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">System Reports</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel className="px-4 text-[10px] uppercase tracking-widest font-bold text-white/30">Asset Matrix</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard/inventory'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard/inventory">
                          <Package className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">Stock Units</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard/items'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard/items">
                          <Boxes className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">Item Catalog</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild isActive={pathname === '/dashboard/expenses'} className="h-14 rounded-2xl px-4 hover:bg-white/5">
                        <Link href="/dashboard/expenses">
                          <Wallet className="w-5 h-5 text-primary" />
                          <span className="font-bold text-white/80">Expense Matrix</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup className="mt-auto mb-6">
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className="h-14 rounded-2xl hover:bg-destructive/10 hover:text-destructive px-4">
                        <Link href="/login">
                          <LogOut className="w-5 h-5" />
                          <span className="font-bold">Eject System</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
          </Sidebar>

          <SidebarInset className="bg-transparent">
            <header className="h-24 border-b border-white/5 flex items-center justify-between px-10 bg-black/20 backdrop-blur-3xl">
              <div className="flex items-center gap-6">
                <SidebarTrigger className="hover:bg-white/5 rounded-xl h-12 w-12 text-white border border-white/5" />
                <div className="flex flex-col">
                  <h1 className="text-xl font-headline font-bold text-white tracking-widest uppercase holographic-text">Access Protocol v4.2</h1>
                  <div className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary animate-ping" />
                    <span className="text-[10px] font-bold text-primary tracking-[0.4em] uppercase opacity-80">Synchronized Stream</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <Popover open={isEditing} onOpenChange={setIsEditing}>
                  <PopoverTrigger asChild>
                    <div className="flex items-center gap-4 cursor-pointer glass-pill p-3 rounded-[32px] transition-all border-white/10 hover:border-primary/40 group">
                      <div className="hidden md:flex flex-col items-end px-2">
                        <span className="text-sm font-bold text-white group-hover:text-primary transition-colors">{userName}</span>
                        <span className="text-[9px] text-primary font-bold uppercase tracking-widest">Root Entity</span>
                      </div>
                      <div className="w-12 h-12 rounded-full border-2 border-primary overflow-hidden shadow-[0_0_20px_rgba(0,255,255,0.4)] relative">
                        <img src={avatar} alt="Avatar" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Camera className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </div>
                  </PopoverTrigger>
                  <PopoverContent className="w-96 p-8 rounded-[40px] glass-panel border-white/10 text-white shadow-2xl" align="end">
                    <div className="space-y-8">
                      <div className="space-y-2">
                        <h4 className="font-headline font-bold text-primary text-xl uppercase tracking-widest">Identity Protocol</h4>
                        <p className="text-[10px] text-white/40 uppercase font-bold tracking-widest">Update your terminal manifestation.</p>
                      </div>
                      
                      <div className="flex flex-col items-center gap-6">
                        <div className="relative group/avatar">
                          <div className="w-32 h-32 rounded-[32px] border-2 border-primary overflow-hidden shadow-[0_0_40px_rgba(0,255,255,0.3)] bg-white/5">
                            <img src={avatar} alt="Large Avatar" className="w-full h-full object-cover" />
                          </div>
                          <label className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-primary hover:bg-primary/90 text-black p-3 rounded-2xl cursor-pointer shadow-xl transition-transform hover:scale-110">
                            <Camera className="w-5 h-5" />
                            <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                          </label>
                        </div>
                      </div>

                      <div className="space-y-6 pt-4">
                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-4">Display Alias</Label>
                          <Input value={tempName} onChange={(e) => setTempName(e.target.value)} className="h-14 rounded-2xl bg-white/5 border-white/10 text-white font-bold" />
                        </div>
                        
                        <div className="space-y-4">
                          <p className="text-[10px] uppercase font-bold tracking-widest text-white/40 ml-4">Neural Binding</p>
                          <div className="grid grid-cols-2 gap-3">
                            <Button 
                              variant="outline" 
                              onClick={() => handleBind('Gmail')}
                              className="h-14 rounded-2xl border-white/10 hover:bg-white/5 text-[10px] uppercase font-bold tracking-widest gap-2"
                            >
                              <Mail className="w-4 h-4 text-primary" /> Gmail
                            </Button>
                            <Button 
                              variant="outline" 
                              onClick={() => handleBind('Telegram')}
                              className="h-14 rounded-2xl border-white/10 hover:bg-white/5 text-[10px] uppercase font-bold tracking-widest gap-2"
                            >
                              <Send className="w-4 h-4 text-[#24A1DE]" /> Telegram
                            </Button>
                          </div>
                        </div>

                        <Button onClick={handleSaveChanges} className="w-full h-16 rounded-2xl bg-primary text-black font-bold shadow-xl shadow-primary/20 hover:scale-[1.02] transition-all">
                          <Save className="w-5 h-5 mr-2" />
                          Commit Matrix
                        </Button>
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </header>
            <main className="p-10 overflow-y-auto h-[calc(100vh-96px)]">
              <motion.div
                key={pathname}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
              >
                {children}
              </motion.div>
            </main>
          </SidebarInset>
        </div>
      </div>

      <AnimatePresence>
        {showCropper && image && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-6"
          >
            <div className="w-full max-w-2xl bg-white/5 border border-white/10 rounded-[48px] overflow-hidden flex flex-col shadow-2xl">
              <div className="h-20 px-8 flex items-center justify-between border-b border-white/10">
                <span className="text-[10px] uppercase font-bold tracking-[0.4em] text-primary">Visual Asset Alignment</span>
                <Button variant="ghost" size="icon" onClick={() => setShowCropper(false)} className="text-white/40 hover:text-white rounded-xl">
                  <X className="w-6 h-6" />
                </Button>
              </div>
              
              <div className="relative h-[400px] w-full bg-black">
                <Cropper
                  image={image}
                  crop={crop}
                  zoom={zoom}
                  aspect={1}
                  onCropChange={setCrop}
                  onCropComplete={onCropComplete}
                  onZoomChange={setZoom}
                  cropShape="round"
                  showGrid={false}
                />
              </div>

              <div className="p-10 space-y-8 bg-black/40">
                <div className="flex items-center gap-6">
                  <ZoomOut className="w-5 h-5 text-white/40" />
                  <Slider
                    value={[zoom]}
                    min={1}
                    max={3}
                    step={0.1}
                    onValueChange={([val]) => setZoom(val)}
                    className="flex-1"
                  />
                  <ZoomIn className="w-5 h-5 text-white/40" />
                </div>
                
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setShowCropper(false)} className="flex-1 h-14 rounded-2xl border-white/10 text-white font-bold uppercase tracking-widest">
                    Cancel
                  </Button>
                  <Button onClick={handleSaveCrop} className="flex-1 h-14 rounded-2xl bg-primary text-black font-bold uppercase tracking-widest shadow-xl shadow-primary/20">
                    Extract Data
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </SidebarProvider>
  );
}
