
'use client';

import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Package, PlusCircle, Trash2, Layers } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { initializeFirebase, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';

export default function InventoryPage() {
  const { db } = initializeFirebase();
  const { toast } = useToast();
  
  const [itemName, setItemName] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('');
  const [unitCost, setUnitCost] = useState<string>('');
  const [category, setCategory] = useState<string>('');

  const inventoryQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'inventory'), orderBy('createdAt', 'desc'));
  }, [db]);

  const { data: inventory, loading } = useCollection(inventoryQuery);

  const handleAddStock = async () => {
    if (!itemName || !quantity) {
      toast({
        title: "Incomplete Protocol",
        description: "Please define the asset name and quantity.",
        variant: "destructive"
      });
      return;
    }

    if (!db) return;

    try {
      await addDoc(collection(db, 'inventory'), {
        name: itemName,
        quantity: parseInt(quantity),
        unitCost: parseFloat(unitCost || '0'),
        category: category || 'Uncategorized',
        lastUpdated: new Date().toISOString(),
        createdAt: serverTimestamp()
      });
      
      toast({
        title: "Asset Recorded",
        description: `${quantity} units of ${itemName} integrated into neural stock.`,
      });

      setItemName('');
      setQuantity('');
      setUnitCost('');
      setCategory('');
    } catch (error: any) {
      toast({ title: "Sync Error", description: error.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    try {
      await deleteDoc(doc(db, 'inventory', id));
      toast({
        title: "Asset Ejected",
        description: "Stock unit removed from the system registry.",
      });
    } catch (error: any) {
      toast({ title: "Purge Error", description: error.message, variant: "destructive" });
    }
  };

  const totalInventoryValue = (inventory || []).reduce((acc, curr) => acc + ((Number(curr.quantity) || 0) * (Number(curr.unitCost) || 0)), 0);
  const totalItemsCount = (inventory || []).reduce((acc, curr) => acc + (Number(curr.quantity) || 0), 0);

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary border border-primary/20">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-headline font-bold text-accent holographic-text uppercase tracking-widest">Stock Units</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-[0.2em] opacity-60">Asset Matrix Control</p>
          </div>
        </div>
        <Card className="glass-panel border-none px-6 py-4 bg-primary/5 rounded-3xl">
          <p className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-1">Total Stock Valuation</p>
          <p className="text-2xl font-headline font-bold text-primary">₱{totalInventoryValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 glass-panel border-white/5 rounded-[32px] h-fit">
          <CardHeader>
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/40">Resource Intake</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Asset Name</Label>
              <Input 
                placeholder="e.g. Raw Material A, Packaging"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Quantity</Label>
                <Input 
                  type="number"
                  placeholder="0"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="h-14 rounded-2xl bg-white/5 border-white/10 text-xl font-headline font-bold text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Unit Cost (₱)</Label>
                <Input 
                  type="number"
                  placeholder="0.00"
                  value={unitCost}
                  onChange={(e) => setUnitCost(e.target.value)}
                  className="h-14 rounded-2xl bg-white/5 border-white/10 text-xl font-headline font-bold text-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Matrix Category</Label>
              <Input 
                placeholder="e.g. Supplies, Raw"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-white"
              />
            </div>

            <Button 
              onClick={handleAddStock}
              className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-white font-bold shadow-xl shadow-primary/20 mt-2"
            >
              <PlusCircle className="w-5 h-5 mr-2" />
              Initialize Asset
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 glass-panel border-white/5 rounded-[32px] overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-accent">Active Inventory Manifest</CardTitle>
            <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/5">
               <Layers className="w-4 h-4 text-primary" />
               <span className="text-[10px] font-bold text-white/80 uppercase tracking-widest">{totalItemsCount} Total Units</span>
            </div>
          </CardHeader>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5">
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 pl-8">Asset Name</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-center">Qty</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-right">Value/Unit</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-right">Total Matrix</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-center pr-8">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-white/20 py-20 text-xs italic">SYNCHRONIZING ASSETS...</TableCell></TableRow>
                ) : !inventory?.length ? (
                  <TableRow><TableCell colSpan={5} className="text-center text-white/20 py-20 text-xs italic">MATRIX IS CURRENTLY EMPTY</TableCell></TableRow>
                ) : (
                  inventory.map((item) => (
                    <TableRow key={item.id} className="hover:bg-white/5 border-white/5 transition-colors">
                      <TableCell className="text-xs font-bold text-white pl-8">
                        {item.name}
                        <p className="text-[9px] text-white/20 uppercase font-bold tracking-widest">{item.category}</p>
                      </TableCell>
                      <TableCell className="text-xs font-bold text-center">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${item.quantity < 10 ? 'bg-destructive/20 text-red-500 border border-red-500/20' : 'bg-primary/20 text-primary border border-primary/20'}`}>
                          {item.quantity}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs text-right text-white/60">₱{(Number(item.unitCost) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-xs font-bold text-right text-primary">₱{((Number(item.quantity) || 0) * (Number(item.unitCost) || 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-center pr-8">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDelete(item.id)}
                          className="h-8 w-8 text-destructive hover:bg-destructive/10 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  );
}
