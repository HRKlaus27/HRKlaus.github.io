'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { KpiSummaryCard } from '@/components/KpiSummaryCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Zap, ShoppingBag, TrendingUp, ArrowUpRight, ArrowDownRight, Search, PlusCircle, Coins, Calendar as CalendarIcon, Sparkles, AlertCircle, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { initializeFirebase, useCollection, errorEmitter, FirestorePermissionError } from '@/firebase';
import { collection, addDoc, serverTimestamp, query, orderBy, limit, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

export default function DashboardPage() {
  const { db } = initializeFirebase();
  const { toast } = useToast();
  
  const salesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'sales'), orderBy('timestamp', 'desc'), limit(50));
  }, [db]);

  const expensesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'expenses'), orderBy('timestamp', 'desc'));
  }, [db]);
  
  const { data: salesDataFromDb, loading: loadingSales } = useCollection(salesQuery);
  const { data: expensesDataFromDb } = useCollection(expensesQuery);

  const [saleAmount, setSaleAmount] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [useCustomDate, setUseCustomDate] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Edit State
  const [editingSale, setEditingSale] = useState<any | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editAmount, setEditAmount] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editDate, setEditDate] = useState<Date | undefined>(undefined);

  useEffect(() => {
    setMounted(true);
    setDate(new Date());
  }, []);

  const totalRevenue = useMemo(() => (salesDataFromDb || []).reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0), [salesDataFromDb]);
  const totalExpenses = useMemo(() => (expensesDataFromDb || []).reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0), [expensesDataFromDb]);
  const netProfit = totalRevenue - totalExpenses;

  const handleSaveSale = () => {
    if (!saleAmount || parseFloat(saleAmount) <= 0) {
      toast({ title: "Invalid Input", description: "Please enter a valid amount.", variant: "destructive" });
      return;
    }
    if (!db) return;

    const saleAmountNum = parseFloat(saleAmount);
    const saleDate = useCustomDate && date ? date : new Date();
    const data = {
      amount: saleAmountNum,
      description: description || 'Direct Entry',
      timestamp: saleDate.toISOString(),
      createdAt: serverTimestamp()
    };

    addDoc(collection(db, 'sales'), data)
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: 'sales',
          operation: 'create',
          requestResourceData: data,
        }));
      });

    toast({ title: "Data Stream Updated", description: `₱${saleAmountNum.toLocaleString()} recorded securely.` });
    setSaleAmount('');
    setDescription('');
  };

  const handleEditClick = (sale: any) => {
    setEditingSale(sale);
    setEditAmount(sale.amount.toString());
    setEditDescription(sale.description || '');
    setEditDate(new Date(sale.timestamp || Date.now()));
    setIsEditDialogOpen(true);
  };

  const handleUpdateSale = () => {
    if (!editingSale || !db) return;
    
    const saleRef = doc(db, 'sales', editingSale.id);
    const updateData = {
      amount: parseFloat(editAmount),
      description: editDescription,
      timestamp: editDate?.toISOString() || editingSale.timestamp
    };

    updateDoc(saleRef, updateData)
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: saleRef.path,
          operation: 'update',
          requestResourceData: updateData,
        }));
      });

    setIsEditDialogOpen(false);
    setEditingSale(null);
    toast({ title: "Protocol Modified", description: "The transaction data has been successfully re-routed." });
  };

  const handleDeleteSale = (id: string) => {
    if (!db) return;
    if (!confirm("Are you sure you want to eject this transaction from the database?")) return;

    const saleRef = doc(db, 'sales', id);
    deleteDoc(saleRef)
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: saleRef.path,
          operation: 'delete',
        }));
      });
      
    toast({ title: "Data Purged", description: "The record has been permanently removed from the system." });
  };

  const salesTrendData = useMemo(() => {
    if (!salesDataFromDb || salesDataFromDb.length === 0) return [];
    return [...salesDataFromDb].slice(0, 7).reverse().map(sale => {
      const dateObj = new Date(sale.timestamp || Date.now());
      return { name: format(dateObj, 'MM/dd'), sales: Number(sale.amount) || 0 };
    });
  }, [salesDataFromDb]);

  const revenueVsExpensesData = [
    { name: 'Revenue', value: totalRevenue, color: '#ffffff' },
    { name: 'Expenses', value: totalExpenses, color: '#f87171' },
  ];

  if (!mounted) return null;

  return (
    <div className="space-y-6 pb-10 text-white">
      {!db && (
        <div className="bg-destructive/10 border border-destructive/20 p-4 rounded-2xl flex items-center gap-3 text-destructive animate-pulse">
          <AlertCircle className="w-5 h-5" />
          <p className="text-xs font-bold uppercase tracking-widest">System Warning: Firebase API Disconnected.</p>
        </div>
      )}

      <KpiSummaryCard />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        <section className="lg:col-span-3">
          <Card className="glass-panel border-white/10 overflow-hidden rounded-[32px]">
            <CardHeader className="py-4 px-8 bg-white/5 border-b border-white/5 flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary animate-pulse" />
                <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/80">Input Terminal</CardTitle>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="custom-date-mode" 
                    checked={useCustomDate} 
                    onCheckedChange={setUseCustomDate}
                    className="data-[state=checked]:bg-primary"
                  />
                  <Label htmlFor="custom-date-mode" className="text-[9px] uppercase font-bold text-white/40 tracking-widest cursor-pointer">Backdate Protocol</Label>
                </div>
                <Badge variant="outline" className={`text-[9px] px-3 py-1 uppercase font-bold tracking-widest ${db ? 'border-primary/40 text-primary bg-primary/5' : 'border-white/10 text-white/40'}`}>
                  {db ? 'System Active' : 'Offline Mode'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <div className="flex flex-col items-center justify-center py-6">
                <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-white/40 mb-2">Transaction Value</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-headline font-bold text-white/40">₱</span>
                  <span className="text-7xl font-headline font-bold text-white tracking-tighter">
                    {saleAmount ? parseFloat(saleAmount).toLocaleString(undefined, { minimumFractionDigits: 2 }) : '0.00'}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-3 relative">
                  <Coins className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                  <Input type="number" placeholder="0.00" value={saleAmount} onChange={(e) => setSaleAmount(e.target.value)} className="pl-12 h-14 bg-white/5 border-white/10 rounded-2xl text-xl font-headline font-bold text-white focus-visible:ring-primary/40" />
                </div>
                <div className="md:col-span-4 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
                  <Input placeholder="Remarks" value={description} onChange={(e) => setDescription(e.target.value)} className="pl-12 h-14 bg-white/5 border-white/10 rounded-2xl text-white" />
                </div>
                <div className="md:col-span-3">
                  <Popover>
                    <PopoverTrigger asChild disabled={!useCustomDate}>
                      <Button
                        variant={"outline"}
                        className={`w-full h-14 rounded-2xl bg-white/5 border-white/10 text-white justify-start text-left font-normal ${!useCustomDate && 'opacity-30 cursor-not-allowed'}`}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                        {date ? format(date, "PPP") : <span>Protocol Date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 rounded-3xl bg-black/90 border-white/10 text-white" align="start">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                        className="rounded-3xl border-none"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="md:col-span-2 flex items-center">
                  <Button onClick={handleSaveSale} disabled={!db} className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-white font-bold shadow-[0_0_20px_rgba(177,134,232,0.4)] transition-all hover:scale-[1.02]">
                    <PlusCircle className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
        
        <section className="lg:col-span-1 space-y-4">
          <StatCard title="Total Credits" value={`₱${totalRevenue.toLocaleString()}`} variant="primary" icon={<ArrowUpRight className="w-4 h-4" />} />
          <StatCard title="Overhead" value={`₱${totalExpenses.toLocaleString()}`} variant="default" icon={<ArrowDownRight className="w-4 h-4" />} />
          <StatCard title="Net Liquid" value={`₱${netProfit.toLocaleString()}`} variant={netProfit >= 0 ? 'accent' : 'destructive'} icon={<Sparkles className="w-4 h-4" />} />
        </section>
      </div>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-panel border-white/10 p-8 rounded-[32px]">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/60 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" /> Volume Progression
            </CardTitle>
          </CardHeader>
          <div className="h-[350px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesTrendData.length > 0 ? salesTrendData : [{name: 'Empty', sales: 0}]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: 'rgba(255,255,255,0.4)'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: 'rgba(255,255,255,0.4)'}} />
                <Tooltip contentStyle={{borderRadius: '16px', border: 'none', backgroundColor: 'rgba(0,0,0,0.8)'}} />
                <Bar dataKey="sales" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="glass-panel border-white/10 p-8 rounded-[32px]">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/60 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-accent" /> 3D Resource Distribution Matrix
            </CardTitle>
          </CardHeader>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <defs>
                  <filter id="pieShadow" height="150%">
                    <feDropShadow dx="0" dy="5" stdDeviation="3" floodOpacity="0.5" />
                  </filter>
                </defs>
                <Pie
                  data={revenueVsExpensesData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={10}
                  cornerRadius={10}
                  dataKey="value"
                  animationDuration={1500}
                >
                  {revenueVsExpensesData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" style={{ filter: 'url(#pieShadow)' }} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{borderRadius: '16px', border: 'none', backgroundColor: 'rgba(0,0,0,0.8)'}} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </section>

      <Card className="glass-panel border-white/10 overflow-hidden rounded-[32px]">
        <Table>
          <TableHeader className="bg-white/5">
            <TableRow className="border-white/5 hover:bg-transparent">
              <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 pl-8">Timestamp</TableHead>
              <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14">Protocol / Remarks</TableHead>
              <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-right">Magnitude</TableHead>
              <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-center pr-8">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loadingSales ? (
              <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">SYNCHRONIZING...</TableCell></TableRow>
            ) : !salesDataFromDb?.length ? (
              <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">NO ACTIVE DATA STREAM</TableCell></TableRow>
            ) : (
              salesDataFromDb.map((sale) => (
                <TableRow key={sale.id} className="hover:bg-white/5 border-white/5">
                  <TableCell className="text-xs text-white/60 pl-8">{format(new Date(sale.timestamp || Date.now()), 'MM.dd.yy HH:mm')}</TableCell>
                  <TableCell className="text-xs font-bold text-white">{sale.description}</TableCell>
                  <TableCell className="text-right text-xs font-bold text-primary">₱{(Number(sale.amount) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                  <TableCell className="text-center pr-8">
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleEditClick(sale)} className="h-8 w-8 text-primary hover:bg-primary/10 rounded-lg">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteSale(sale.id)} className="h-8 w-8 text-destructive hover:bg-primary/10 rounded-lg">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="glass-panel border-white/10 rounded-[32px] text-white p-8 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-headline font-bold holographic-text uppercase tracking-widest flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" /> Modify Transaction
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-6">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold tracking-[0.3em] text-white/40">Amount (₱)</Label>
              <Input 
                type="number" 
                value={editAmount} 
                onChange={(e) => setEditAmount(e.target.value)} 
                className="h-12 bg-white/5 border-white/10 rounded-xl font-bold"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold tracking-[0.3em] text-white/40">Remarks</Label>
              <Input 
                value={editDescription} 
                onChange={(e) => setEditDescription(e.target.value)} 
                className="h-12 bg-white/5 border-white/10 rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold tracking-[0.3em] text-white/40">Protocol Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full h-12 bg-white/5 border-white/10 rounded-xl justify-start font-normal text-white">
                    <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                    {editDate ? format(editDate, "PPP") : "Select Date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 rounded-3xl bg-black border-white/10" align="start">
                  <Calendar mode="single" selected={editDate} onSelect={setEditDate} className="bg-black text-white rounded-3xl" />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <DialogFooter className="flex gap-4 mt-4">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1 h-12 rounded-xl border-white/10 hover:bg-white/5">
              Abort
            </Button>
            <Button onClick={handleUpdateSale} className="flex-1 h-12 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/20">
              Commit Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatCard({ title, value, variant = 'default', icon }: any) {
  return (
    <Card className="glass-panel border-white/5 transition-all hover:scale-[1.02] rounded-3xl group">
      <CardContent className="p-6 flex flex-col justify-center min-h-[120px] relative overflow-hidden">
        <p className="text-[9px] text-white/40 font-bold uppercase tracking-[0.3em] mb-2">{title}</p>
        <div className="flex items-center justify-between">
          <p className={`text-3xl font-headline font-bold tracking-tight ${variant === 'primary' ? 'text-primary' : variant === 'accent' ? 'text-accent' : variant === 'destructive' ? 'text-red-500' : 'text-white'}`}>{value}</p>
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${variant === 'primary' ? 'bg-primary/20 text-primary' : variant === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-white/60'}`}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}
