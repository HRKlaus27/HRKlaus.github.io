
'use client';

import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Wallet, PlusCircle, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { initializeFirebase, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';

export default function ExpensesPage() {
  const { db } = initializeFirebase();
  const { toast } = useToast();
  
  const [category, setCategory] = useState<string>('Rent');
  const [customCategory, setCustomCategory] = useState<string>('');
  const [amount, setAmount] = useState<string>('');

  const expensesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'expenses'), orderBy('timestamp', 'desc'));
  }, [db]);

  const { data: expenses, loading } = useCollection(expensesQuery);

  const handleAddExpense = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid expense amount.",
        variant: "destructive"
      });
      return;
    }

    if (!db) return;

    try {
      const finalCategory = category === 'Other' ? customCategory || 'Other' : category;
      await addDoc(collection(db, 'expenses'), {
        category: finalCategory,
        amount: parseFloat(amount),
        timestamp: new Date().toISOString(),
        createdAt: serverTimestamp()
      });

      toast({
        title: "Expense Logged",
        description: `₱${parseFloat(amount).toLocaleString()} for ${finalCategory} saved to secure ledger.`,
      });

      setAmount('');
      setCustomCategory('');
    } catch (error: any) {
      toast({ title: "Sync Error", description: error.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    try {
      await deleteDoc(doc(db, 'expenses', id));
      toast({
        title: "Protocol Purged",
        description: "The expense record has been permanently removed.",
      });
    } catch (error: any) {
      toast({ title: "Purge Error", description: error.message, variant: "destructive" });
    }
  };

  const totalExpenses = (expenses || []).reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center text-accent border border-accent/20">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-headline font-bold text-accent holographic-text uppercase tracking-widest">Expense Matrix</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-[0.2em] opacity-60">System Overhead Tracking</p>
          </div>
        </div>
        <Card className="glass-panel border-none px-6 py-4 bg-accent/5 rounded-3xl">
          <p className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-1">Total Period Overhead</p>
          <p className="text-2xl font-headline font-bold text-accent">₱{totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 glass-panel border-white/5 rounded-[32px] h-fit">
          <CardHeader>
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/40">Record Protocol</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-14 rounded-2xl bg-white/5 border-white/10 text-white font-bold">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="rounded-2xl bg-black border-white/10 text-white">
                  <SelectItem value="Rent">Rent</SelectItem>
                  <SelectItem value="Water">Water</SelectItem>
                  <SelectItem value="WiFi">WiFi</SelectItem>
                  <SelectItem value="Electricity">Electricity</SelectItem>
                  <SelectItem value="Other">Other (Custom)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {category === 'Other' && (
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Custom Alias</Label>
                <Input 
                  placeholder="e.g. Repairs, Supplies"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="h-14 rounded-2xl bg-white/5 border-white/10 text-white"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Magnitude (₱)</Label>
              <Input 
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-2xl font-headline font-bold text-accent"
              />
            </div>

            <Button 
              onClick={handleAddExpense}
              className="w-full h-14 rounded-2xl bg-accent hover:bg-accent/90 text-black font-bold shadow-xl shadow-accent/20"
            >
              <PlusCircle className="w-5 h-5 mr-2" />
              Commit Expense
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 glass-panel border-white/5 rounded-[32px] overflow-hidden">
          <CardHeader>
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-accent">Data Stream History</CardTitle>
          </CardHeader>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5">
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 pl-8">Date</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14">Category</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-right">Amount</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-center pr-8">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">SYNCHRONIZING...</TableCell></TableRow>
                ) : !expenses?.length ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">NO DATA PACKETS FOUND</TableCell></TableRow>
                ) : (
                  expenses.map((expense) => (
                    <TableRow key={expense.id} className="hover:bg-white/5 border-white/5 transition-colors">
                      <TableCell className="text-xs text-white/60 pl-8">{format(new Date(expense.timestamp), 'MMM dd, yyyy')}</TableCell>
                      <TableCell className="text-xs font-bold text-white">{expense.category}</TableCell>
                      <TableCell className="text-xs font-bold text-right text-accent">₱{(Number(expense.amount) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-center pr-8">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDelete(expense.id)}
                          className="h-8 w-8 text-destructive hover:bg-destructive/10 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  );
}
