
'use client';

import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Boxes, PlusCircle, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { initializeFirebase, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';

export default function ItemsPage() {
  const { db } = initializeFirebase();
  const { toast } = useToast();
  
  const [itemName, setItemName] = useState<string>('');
  const [itemPrice, setItemPrice] = useState<string>('');
  const [itemDescription, setItemDescription] = useState<string>('');

  const itemsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'items'), orderBy('createdAt', 'desc'));
  }, [db]);

  const { data: items, loading } = useCollection(itemsQuery);

  const handleAddItem = async () => {
    if (!itemName || !itemPrice) {
      toast({
        title: "Information Deficit",
        description: "Please enter the product/service name and standard price.",
        variant: "destructive"
      });
      return;
    }

    if (!db) return;

    try {
      await addDoc(collection(db, 'items'), {
        name: itemName,
        price: parseFloat(itemPrice),
        description: itemDescription || 'No description',
        createdAt: serverTimestamp()
      });
      
      toast({
        title: "Catalog Updated",
        description: `${itemName} has been integrated into the system catalog.`,
      });

      setItemName('');
      setItemPrice('');
      setItemDescription('');
    } catch (error: any) {
      toast({ title: "Sync Error", description: error.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    try {
      await deleteDoc(doc(db, 'items', id));
      toast({
        title: "Object Purged",
        description: "The item has been successfully removed from the neural catalog.",
      });
    } catch (error: any) {
      toast({ title: "Purge Error", description: error.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary border border-primary/20">
            <Boxes className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-headline font-bold text-accent holographic-text uppercase tracking-widest">Item Catalog</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-[0.2em] opacity-60">System Core Offerings</p>
          </div>
        </div>
        <Card className="glass-panel border-none px-6 py-4 bg-primary/5 rounded-3xl">
          <p className="text-[10px] uppercase font-bold tracking-widest text-white/40 mb-1">Catalog Density</p>
          <p className="text-2xl font-headline font-bold text-primary">{(items || []).length} Objects</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1 glass-panel border-white/5 rounded-[32px] h-fit">
          <CardHeader>
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/40">New Matrix Entry</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Item Identity</Label>
              <Input 
                placeholder="e.g. Premium Service, Product A"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Standard Price (₱)</Label>
              <Input 
                type="number"
                placeholder="0.00"
                value={itemPrice}
                onChange={(e) => setItemPrice(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-2xl font-headline font-bold text-white"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-white/40 tracking-widest ml-4">Data Description</Label>
              <Input 
                placeholder="Brief technical details..."
                value={itemDescription}
                onChange={(e) => setItemDescription(e.target.value)}
                className="h-14 rounded-2xl bg-white/5 border-white/10 text-white"
              />
            </div>

            <Button 
              onClick={handleAddItem}
              className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-white font-bold shadow-xl shadow-primary/20 mt-2"
            >
              <PlusCircle className="w-5 h-5 mr-2" />
              Manifest Item
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 glass-panel border-white/5 rounded-[32px] overflow-hidden">
          <CardHeader>
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-accent">Central Catalog Grid</CardTitle>
          </CardHeader>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow className="border-white/5">
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 pl-8">Item Identity</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14">Data Description</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-right">Standard Price</TableHead>
                  <TableHead className="text-[10px] uppercase font-bold text-white/40 h-14 text-center pr-8">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">SYNCING CATALOG...</TableCell></TableRow>
                ) : !items?.length ? (
                  <TableRow><TableCell colSpan={4} className="text-center text-white/20 py-20 text-xs italic">CATALOG IS EMPTY</TableCell></TableRow>
                ) : (
                  items.map((item) => (
                    <TableRow key={item.id} className="hover:bg-white/5 border-white/5 transition-colors">
                      <TableCell className="text-xs font-bold text-white pl-8">{item.name}</TableCell>
                      <TableCell className="text-xs text-white/40">{item.description}</TableCell>
                      <TableCell className="text-xs font-bold text-right text-primary">₱{(Number(item.price) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-center pr-8">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDelete(item.id)}
                          className="h-8 w-8 text-destructive hover:bg-destructive/10 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  );
}
