'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { BarChart3, PieChart as PieIcon, Download, Calendar, TrendingUp, DollarSign, ShoppingCart, Loader2 } from 'lucide-react';
import { initializeFirebase, useCollection } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { format, isSameDay, isSameWeek, isSameMonth, isSameYear, subDays, eachDayOfInterval, startOfWeek, startOfMonth, startOfYear } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

export default function ReportsPage() {
  const { db } = initializeFirebase();
  const [activeTab, setActiveTab] = useState('monthly');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const salesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'sales'), orderBy('timestamp', 'desc'));
  }, [db]);

  const expensesQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'expenses'), orderBy('timestamp', 'desc'));
  }, [db]);

  const { data: salesData, loading: salesLoading } = useCollection(salesQuery);
  const { data: expensesData, loading: expensesLoading } = useCollection(expensesQuery);

  const handlePrint = () => {
    window.print();
  };

  const processedData = useMemo(() => {
    if (!mounted || salesLoading || expensesLoading) return null;

    const sales = salesData || [];
    const expenses = expensesData || [];

    const now = new Date();
    const getDate = (item: any) => {
      if (item.timestamp?.seconds) return new Date(item.timestamp.seconds * 1000);
      return new Date(item.timestamp || Date.now());
    };

    let interval: { name: string, sales: number, expenses: number }[] = [];

    if (activeTab === 'daily') {
      const last7Days = eachDayOfInterval({ start: subDays(now, 6), end: now });
      interval = last7Days.map(date => ({
        name: format(date, 'EEE'),
        sales: sales.filter(s => isSameDay(getDate(s), date)).reduce((acc, s) => acc + (Number(s.amount) || 0), 0),
        expenses: expenses.filter(e => isSameDay(getDate(e), date)).reduce((acc, e) => acc + (Number(e.amount) || 0), 0)
      }));
    } else if (activeTab === 'weekly') {
      for (let i = 3; i >= 0; i--) {
        const weekStart = startOfWeek(subDays(now, i * 7));
        interval.push({
          name: `Week ${4-i}`,
          sales: sales.filter(s => isSameWeek(getDate(s), weekStart)).reduce((acc, s) => acc + (Number(s.amount) || 0), 0),
          expenses: expenses.filter(e => isSameWeek(getDate(e), weekStart)).reduce((acc, e) => acc + (Number(e.amount) || 0), 0)
        });
      }
    } else if (activeTab === 'monthly') {
      for (let i = 5; i >= 0; i--) {
        const monthStart = startOfMonth(subDays(now, i * 30));
        interval.push({
          name: format(monthStart, 'MMM'),
          sales: sales.filter(s => isSameMonth(getDate(s), monthStart)).reduce((acc, s) => acc + (Number(s.amount) || 0), 0),
          expenses: expenses.filter(e => isSameMonth(getDate(e), monthStart)).reduce((acc, e) => acc + (Number(e.amount) || 0), 0)
        });
      }
    } else if (activeTab === 'annual') {
      for (let i = 1; i >= 0; i--) {
        const yearStart = startOfYear(subDays(now, i * 365));
        interval.push({
          name: format(yearStart, 'yyyy'),
          sales: sales.filter(s => isSameYear(getDate(s), yearStart)).reduce((acc, s) => acc + (Number(s.amount) || 0), 0),
          expenses: expenses.filter(e => isSameYear(getDate(e), yearStart)).reduce((acc, e) => acc + (Number(e.amount) || 0), 0)
        });
      }
    }

    const totalSales = interval.reduce((acc, curr) => acc + curr.sales, 0);
    const totalExpenses = interval.reduce((acc, curr) => acc + curr.expenses, 0);
    const totalTransactions = sales.length;

    const distributionData = [
      { name: 'Total Revenue', value: totalSales, color: '#ffffff' },
      { name: 'Total Overhead', value: totalExpenses, color: '#f87171' }
    ];

    return { interval, totalSales, totalExpenses, totalTransactions, distributionData };
  }, [salesData, expensesData, salesLoading, expensesLoading, activeTab, mounted]);

  const isLoading = !mounted || salesLoading || expensesLoading;

  if (!mounted) return null;

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
            <BarChart3 className="text-primary w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-headline font-bold text-accent holographic-text">Business Intelligence</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-[0.2em] opacity-60">Automated 3D visualized analytics for SKYnet operations.</p>
          </div>
        </div>
        <Button 
          onClick={handlePrint} 
          disabled={isLoading}
          className="h-11 rounded-xl bg-primary hover:bg-primary/90 text-white font-bold flex items-center gap-2 print:hidden shadow-lg shadow-primary/20 transition-all active:scale-95"
        >
          <PieIcon className="w-5 h-5" />
          <span>Export Terminal Report</span>
          <Download className="w-4 h-4 ml-1" />
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full print:hidden">
        <TabsList className="grid grid-cols-4 w-full md:w-[500px] h-14 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-1.5">
          <TabsTrigger value="daily" className="rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] data-[state=active]:bg-primary data-[state=active]:text-white transition-all">Daily</TabsTrigger>
          <TabsTrigger value="weekly" className="rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] data-[state=active]:bg-primary data-[state=active]:text-white transition-all">Weekly</TabsTrigger>
          <TabsTrigger value="monthly" className="rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] data-[state=active]:bg-primary data-[state=active]:text-white transition-all">Monthly</TabsTrigger>
          <TabsTrigger value="annual" className="rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] data-[state=active]:bg-primary data-[state=active]:text-white transition-all">Annual</TabsTrigger>
        </TabsList>
        <div className="mt-8">
           <ReportView title={`${activeTab.toUpperCase()} Matrix Analysis`} data={processedData?.interval || []} totals={processedData} isLoading={isLoading} />
        </div>
      </Tabs>

      <div className="hidden print:block text-black">
        <div className="text-center mb-8 border-b-2 border-black pb-6">
          <h1 className="text-3xl font-headline font-bold uppercase tracking-widest">PROJECT SKYnet Official Report</h1>
          <p className="mt-2 font-bold">Protocol Type: {activeTab.toUpperCase()} Performance Analytics</p>
          <p className="text-sm">Generated on: {new Date().toLocaleDateString()}</p>
        </div>
        {processedData && (
          <ReportView title={`${activeTab.toUpperCase()} Data Manifest`} data={processedData.interval} totals={processedData} isLoading={false} />
        )}
      </div>
    </div>
  );
}

function ReportView({ title, data, totals, isLoading }: { title: string, data: any[], totals: any, isLoading: boolean }) {
  const avgSales = totals ? (totals.totalSales / (data.length || 1)) : 0;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Period Revenue" value={isLoading ? "SYNCING..." : `₱${totals?.totalSales.toLocaleString() || '0'}`} icon={<DollarSign className="w-4 h-4" />} trend="LIVE" isLoading={isLoading} />
        <StatCard title="Node Transactions" value={isLoading ? "SYNCING..." : (totals?.totalTransactions.toString() || '0')} icon={<ShoppingCart className="w-4 h-4" />} trend="SYNCED" isLoading={isLoading} />
        <StatCard title="Avg Performance" value={isLoading ? "SYNCING..." : `₱${avgSales.toLocaleString(undefined, { maximumFractionDigits: 0 }) || '0'}`} icon={<TrendingUp className="w-4 h-4" />} trend="REAL-TIME" isLoading={isLoading} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="glass-panel border-white/10 p-8 rounded-[32px] bg-black/40 backdrop-blur-2xl">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/60 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" /> {title}
            </CardTitle>
          </CardHeader>
          <div className="h-[450px] relative">
            {isLoading ? (
               <div className="absolute inset-0 flex items-center justify-center flex-col gap-4">
                  <Loader2 className="w-8 h-8 text-primary animate-spin" />
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Accessing Matrix...</p>
               </div>
            ) : (!data || data.length === 0 || data.every(d => d.sales === 0 && d.expenses === 0)) ? (
              <div className="h-full flex items-center justify-center text-white/20 text-[10px] uppercase font-bold tracking-widest italic">No Data Stream Detected</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: 'rgba(255,255,255,0.4)'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: 'rgba(255,255,255,0.4)'}} />
                  <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{borderRadius: '24px', border: 'none', backgroundColor: 'rgba(0,0,0,0.9)', color: '#fff'}} />
                  <Bar dataKey="sales" fill="hsl(var(--primary))" radius={[12, 12, 0, 0]} name="Revenue" />
                  <Bar dataKey="expenses" fill="hsl(var(--accent))" radius={[12, 12, 0, 0]} name="Expenses" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="glass-panel border-white/10 p-8 rounded-[32px] bg-black/40 backdrop-blur-2xl">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/60 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-accent" /> 3D Resource Distribution Matrix
            </CardTitle>
          </CardHeader>
          <div className="h-[450px] relative">
            {isLoading ? (
               <div className="absolute inset-0 flex items-center justify-center flex-col gap-4">
                  <Loader2 className="w-8 h-8 text-accent animate-spin" />
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Analyzing Nodes...</p>
               </div>
            ) : (!totals || totals.totalSales === 0) ? (
              <div className="h-full flex items-center justify-center text-white/20 text-[10px] uppercase font-bold tracking-widest italic">Matrix is Currently Idle</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <defs>
                    <filter id="shadow" height="200%">
                      <feDropShadow dx="2" dy="5" stdDeviation="3" floodOpacity="0.5" />
                    </filter>
                  </defs>
                  <Pie
                    data={totals.distributionData}
                    cx="50%"
                    cy="45%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={8}
                    cornerRadius={12}
                    dataKey="value"
                    isAnimationActive={true}
                    animationDuration={1000}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={{ stroke: 'rgba(255,255,255,0.2)', strokeWidth: 1 }}
                  >
                    {totals.distributionData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="rgba(255,255,255,0.1)" strokeWidth={2} style={{ filter: 'url(#shadow)' }} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{borderRadius: '24px', border: 'none', backgroundColor: 'rgba(0,0,0,0.9)', color: '#fff'}} />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ paddingTop: '30px', fontSize: '10px', textTransform: 'uppercase', letterSpacing: '2px' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, trend, isLoading }: { title: string, value: string, icon: React.ReactNode, trend: string, isLoading: boolean }) {
  return (
    <Card className="glass-panel border-white/5 shadow-none transition-all hover:scale-[1.02] cursor-default rounded-[32px] bg-black/40 backdrop-blur-2xl overflow-hidden group">
      <CardContent className="p-8">
        <div className="flex justify-between items-start mb-4">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">{icon}</div>
          <span className="text-[9px] font-bold px-3 py-1 rounded-full border bg-primary/10 text-primary border-primary/20 uppercase tracking-widest">
            {isLoading ? <span className="animate-pulse">SYNCING</span> : trend}
          </span>
        </div>
        <p className="text-[9px] text-white/40 font-bold uppercase tracking-[0.4em] mb-2">{title}</p>
        {isLoading ? (
          <Skeleton className="h-8 w-3/4 bg-white/5 rounded-lg" />
        ) : (
          <p className="text-3xl font-headline font-bold text-white holographic-text">{value}</p>
        )}
      </CardContent>
    </Card>
  );
}
