'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Receipt, Plus, Trash2, Printer, User, FileText, Calendar } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface InvoiceItem {
  id: string;
  name: string;
  qty: number;
  price: number;
}

export default function InvoicePage() {
  const { toast } = useToast();
  const [customerName, setCustomerName] = useState('');
  const [invoiceNo, setInvoiceNo] = useState('');
  const [formattedDate, setFormattedDate] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  
  // New Item State
  const [newItemName, setNewItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState('1');
  const [newItemPrice, setNewItemPrice] = useState('');

  // Handle hydration: Generate invoice number and date only on client mount
  useEffect(() => {
    setInvoiceNo(`INV-${Date.now().toString().slice(-6)}`);
    setFormattedDate(format(new Date(), 'MMM dd, yyyy'));
  }, []);

  const handleAddItem = () => {
    if (!newItemName || !newItemPrice) {
      toast({
        title: "Missing Information",
        description: "Please enter item name and price.",
        variant: "destructive"
      });
      return;
    }

    const item: InvoiceItem = {
      id: Date.now().toString(),
      name: newItemName,
      qty: parseInt(newItemQty) || 1,
      price: parseFloat(newItemPrice) || 0
    };

    setItems([...items, item]);
    setNewItemName('');
    setNewItemQty('1');
    setNewItemPrice('');
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const subtotal = items.reduce((acc, item) => acc + (item.qty * item.price), 0);
  const total = subtotal;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
            <Receipt className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-headline font-bold text-accent">Sales Invoice</h1>
            <p className="text-sm text-muted-foreground">Fill up details to generate a professional resibo.</p>
          </div>
        </div>
        <Button 
          onClick={handlePrint}
          className="h-12 rounded-xl bg-accent hover:bg-accent/90 text-white font-bold flex items-center gap-2 shadow-lg shadow-accent/20"
        >
          <Printer className="w-5 h-5" />
          Print Resibo
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Fill-up Form */}
        <Card className="glass-panel border-none shadow-sm print:hidden">
          <CardHeader>
            <CardTitle className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
              <FileText className="w-4 h-4" /> Invoice Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest flex items-center gap-1">
                  <User className="w-3 h-3" /> Customer Name
                </Label>
                <Input 
                  placeholder="e.g. Juan Dela Cruz" 
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="h-11 rounded-xl bg-primary/5 border-none"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest flex items-center gap-1">
                  <Calendar className="w-3 h-3" /> Invoice No.
                </Label>
                <Input 
                  value={invoiceNo}
                  onChange={(e) => setInvoiceNo(e.target.value)}
                  className="h-11 rounded-xl bg-primary/5 border-none"
                />
              </div>
            </div>

            <div className="p-4 bg-primary/5 rounded-2xl space-y-4">
              <p className="text-[10px] uppercase font-bold text-primary tracking-widest">Add Item to Invoice</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Input 
                  placeholder="Item Name" 
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className="bg-white/50 border-none rounded-xl"
                />
                <Input 
                  type="number"
                  placeholder="Qty" 
                  value={newItemQty}
                  onChange={(e) => setNewItemQty(e.target.value)}
                  className="bg-white/50 border-none rounded-xl"
                />
                <Input 
                  type="number"
                  placeholder="Price (₱)" 
                  value={newItemPrice}
                  onChange={(e) => setNewItemPrice(e.target.value)}
                  className="bg-white/50 border-none rounded-xl"
                />
              </div>
              <Button 
                onClick={handleAddItem}
                variant="outline"
                className="w-full h-11 border-dashed border-primary/30 text-primary hover:bg-primary/10 rounded-xl"
              >
                <Plus className="w-4 h-4 mr-2" /> Add to List
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Current Items</p>
              <div className="border rounded-2xl overflow-hidden border-primary/10">
                <Table>
                  <TableHeader className="bg-primary/5">
                    <TableRow>
                      <TableHead className="text-[10px] font-bold">Item</TableHead>
                      <TableHead className="text-[10px] font-bold text-center">Qty</TableHead>
                      <TableHead className="text-[10px] font-bold text-right">Price</TableHead>
                      <TableHead className="text-[10px] font-bold text-center"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8 text-xs italic">
                          No items added yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      items.map((item) => (
                        <TableRow key={item.id} className="hover:bg-primary/5 transition-colors border-b-primary/5">
                          <TableCell className="text-xs font-medium">{item.name}</TableCell>
                          <TableCell className="text-xs text-center">{item.qty}</TableCell>
                          <TableCell className="text-xs text-right font-bold">₱{item.price.toLocaleString()}</TableCell>
                          <TableCell className="text-center">
                            <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(item.id)} className="h-7 w-7 text-destructive">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resibo Preview */}
        <div className="print:m-0 print:p-0">
          <Card className="bg-white border-2 border-slate-100 rounded-[32px] shadow-2xl p-0 overflow-hidden print:shadow-none print:border-none">
            <div className="bg-slate-50 p-8 border-b border-dashed border-slate-200">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h2 className="text-2xl font-headline font-bold text-accent uppercase tracking-widest">PROJECT SKYnet</h2>
                  <p className="text-[10px] text-muted-foreground font-bold tracking-widest uppercase">Official Sales Receipt</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-accent">{invoiceNo || 'Generating...'}</p>
                  <p className="text-[10px] text-muted-foreground uppercase">{formattedDate || 'Loading...'}</p>
                </div>
              </div>
            </div>
            
            <div className="p-8 space-y-8 min-h-[500px] flex flex-col">
              <div className="flex justify-between border-b pb-4 border-slate-100">
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Billed To:</p>
                  <p className="text-sm font-bold text-slate-800">{customerName || 'Walk-in Customer'}</p>
                </div>
                <div className="text-right space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Payment Status:</p>
                  <span className="text-[10px] px-2 py-0.5 bg-green-100 text-green-700 rounded-full font-bold uppercase tracking-wider">PAID</span>
                </div>
              </div>

              <div className="flex-1">
                <Table>
                  <TableHeader>
                    <TableRow className="border-none hover:bg-transparent">
                      <TableHead className="px-0 h-8 text-[10px] uppercase font-bold text-slate-400">Description</TableHead>
                      <TableHead className="px-0 h-8 text-[10px] uppercase font-bold text-slate-400 text-center">Qty</TableHead>
                      <TableHead className="px-0 h-8 text-[10px] uppercase font-bold text-slate-400 text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id} className="border-b-slate-50 hover:bg-transparent">
                        <TableCell className="px-0 py-4 text-xs font-bold text-slate-700">{item.name}</TableCell>
                        <TableCell className="px-0 py-4 text-xs text-center text-slate-500">{item.qty}</TableCell>
                        <TableCell className="px-0 py-4 text-xs text-right font-bold text-slate-700">₱{(item.qty * item.price).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="space-y-3 pt-6 border-t-2 border-slate-100">
                <div className="flex justify-between items-center">
                  <p className="text-xs text-slate-500 font-medium">Subtotal</p>
                  <p className="text-xs font-bold text-slate-700">₱{total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-xs text-slate-500 font-medium">Tax (0%)</p>
                  <p className="text-xs font-bold text-slate-700">₱0.00</p>
                </div>
                <div className="flex justify-between items-center bg-accent/5 p-4 rounded-2xl">
                  <p className="text-sm font-bold text-accent uppercase tracking-widest">Grand Total</p>
                  <p className="text-xl font-headline font-bold text-accent">₱{total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                </div>
              </div>

              <div className="text-center pt-8 opacity-40">
                <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-slate-400">Thank you for your business!</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
