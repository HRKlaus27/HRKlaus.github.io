'use client';

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { firebaseConfig } from './config';

let firebaseApp: FirebaseApp | null = null;
let firestoreDb: Firestore | null = null;
let firebaseAuth: Auth | null = null;

export function initializeFirebase() {
  const isConfigValid = !!(firebaseConfig.apiKey && firebaseConfig.apiKey !== "");
  if (!isConfigValid) return { app: null, db: null, auth: null };
  
  try {
    if (!firebaseApp) {
      if (getApps().length > 0) {
        firebaseApp = getApp();
      } else {
        firebaseApp = initializeApp(firebaseConfig);
      }
      
      firestoreDb = getFirestore(firebaseApp);
      firebaseAuth = getAuth(firebaseApp);

      if (typeof window !== 'undefined' && firestoreDb) {
        enableIndexedDbPersistence(firestoreDb).catch((err) => {
          if (err.code === 'failed-precondition') {
            console.warn('Multiple tabs open, persistence only enabled in one tab.');
          } else if (err.code === 'unimplemented') {
            console.warn('The current browser does not support persistence.');
          }
        });
      }
    }
    
    return { 
      app: firebaseApp, 
      db: firestoreDb, 
      auth: firebaseAuth 
    };
  } catch (error) {
    console.error("Failed to initialize Firebase:", error);
    return { app: null, db: null, auth: null };
  }
}

export { useCollection } from './firestore/use-collection';
export { useDoc } from './firestore/use-doc';
export { useUser } from './auth/use-user';
export { errorEmitter } from './error-emitter';
export { FirestorePermissionError, type SecurityRuleContext } from './errors';
