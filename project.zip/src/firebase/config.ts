'use client';

// Ang kini nga configuration gi-update na gamit ang imong gihatag nga API Key.
// Ang ubang values mahimo nimong makuha sa imong Firebase Console project settings.
export const firebaseConfig = {
  apiKey: "AQ.Ab8RN6Kgc3XM0ppMIhA-cxXiOQX6wC1mTkgSo0rgW8Rb9n8y-w",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "project-skynet-hub.firebaseapp.com",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "project-skynet-hub",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "project-skynet-hub.appspot.com",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "",
};
