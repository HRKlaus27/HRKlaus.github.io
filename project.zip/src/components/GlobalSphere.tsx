'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const GlobalSphere = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Scene Setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);

    // Globe Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Main Sphere (Base - Deep Realistic Core)
    const geometry = new THREE.SphereGeometry(1.5, 64, 64);
    const material = new THREE.MeshPhongMaterial({
      color: 0x000814, // Deep Midnight Blue
      transparent: true,
      opacity: 0.9,
      shininess: 20,
    });
    const globe = new THREE.Mesh(geometry, material);
    globeGroup.add(globe);

    // Wireframe Overlay (Realistic Grid lines)
    const wireframeGeo = new THREE.SphereGeometry(1.51, 32, 32);
    const wireframeMat = new THREE.MeshBasicMaterial({
      color: 0x00ffff,
      wireframe: true,
      transparent: true,
      opacity: 0.1,
    });
    const wireframe = new THREE.Mesh(wireframeGeo, wireframeMat);
    globeGroup.add(wireframe);

    // Points Layer (Realistic City Lights / Data Nodes)
    const pointsGeo = new THREE.SphereGeometry(1.52, 64, 64);
    const pointsMat = new THREE.PointsMaterial({
      color: 0x00ffff,
      size: 0.015,
      transparent: true,
      opacity: 0.6,
    });
    const points = new THREE.Points(pointsGeo, pointsMat);
    globeGroup.add(points);

    // Atmosphere Glow Layer
    const atmosphereGeo = new THREE.SphereGeometry(1.6, 64, 64);
    const atmosphereMat = new THREE.MeshBasicMaterial({
      color: 0xAB86E8,
      transparent: true,
      opacity: 0.05,
      side: THREE.BackSide
    });
    const atmosphere = new THREE.Mesh(atmosphereGeo, atmosphereMat);
    globeGroup.add(atmosphere);

    // Orbital Rings (Realistic Tech Rings)
    const createRing = (radius: number, rotationX: number, color: number, opacity: number) => {
      const ringGeo = new THREE.TorusGeometry(radius, 0.003, 16, 100);
      const ringMat = new THREE.MeshBasicMaterial({ 
        color, 
        transparent: true, 
        opacity 
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = rotationX;
      return ring;
    };

    const ring1 = createRing(1.8, Math.PI / 2.5, 0x00ffff, 0.2);
    const ring2 = createRing(1.9, -Math.PI / 3, 0xAB86E8, 0.15);
    const ring3 = createRing(2.0, Math.PI / 6, 0xffffff, 0.1);
    globeGroup.add(ring1);
    globeGroup.add(ring2);
    globeGroup.add(ring3);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x00ffff, 2);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    const blueLight = new THREE.PointLight(0xAB86E8, 1.5);
    blueLight.position.set(-5, -5, 5);
    scene.add(blueLight);

    // Animation
    const animate = () => {
      requestAnimationFrame(animate);
      
      globeGroup.rotation.y += 0.003; // Slower, more realistic rotation
      globeGroup.rotation.x += 0.0005;
      
      ring1.rotation.z += 0.008;
      ring2.rotation.z -= 0.006;
      ring3.rotation.z += 0.004;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) containerRef.current.innerHTML = '';
    };
  }, []);

  return <div ref={containerRef} className="w-full h-full" />;
};