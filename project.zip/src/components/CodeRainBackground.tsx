'use client';

import React, { useEffect, useRef } from 'react';

interface CodeRainBackgroundProps {
  color?: string;
  opacity?: number;
  speed?: number;
}

export const CodeRainBackground: React.FC<CodeRainBackgroundProps> = ({ 
  color = '#AB86E8', 
  opacity = 0.4,
  speed = 1
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Character set for the falling code
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$+-*/=%"\'#&_(),.;:?!\\|{}<>[]^~';
    const charArray = characters.split('');
    const fontSize = 16;
    const columns = Math.floor(width / fontSize);
    const drops: number[] = [];

    // Initialize drops at random y positions
    for (let i = 0; i < columns; i++) {
      drops[i] = Math.random() * (height / fontSize);
    }

    const draw = () => {
      // Create trailing effect by drawing a semi-transparent black rectangle
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.fillRect(0, 0, width, height);

      ctx.font = `${fontSize}px monospace`;
      
      for (let i = 0; i < drops.length; i++) {
        // Pick a random character
        const text = charArray[Math.floor(Math.random() * charArray.length)];
        
        // Add glowing effect to the characters
        ctx.shadowBlur = 12;
        ctx.shadowColor = color;
        ctx.fillStyle = color;
        
        // Draw the character at column i, row drops[i]
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        // Reset drop to top if it goes off screen with a bit of randomness
        if (drops[i] * fontSize > height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        // Increment the drop position based on speed
        drops[i] += 1 * speed;
      }
    };

    const intervalId = setInterval(draw, 33);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      // Re-initialize columns if the window is resized
      const newColumns = Math.floor(width / fontSize);
      while(drops.length < newColumns) {
        drops.push(Math.random() * (height / fontSize));
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      clearInterval(intervalId);
    };
  }, [color, speed]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity }}
    />
  );
};
