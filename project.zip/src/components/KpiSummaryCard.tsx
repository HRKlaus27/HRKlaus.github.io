'use client';

import React, { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, TrendingUp, AlertCircle } from 'lucide-react';
import { dailyKpiSummary, DailyKpiSummaryOutput } from '@/ai/flows/daily-kpi-summary';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { initializeFirebase, useCollection } from '@/firebase';
import { collection, query, limit } from 'firebase/firestore';

export const KpiSummaryCard = () => {
  const { db } = initializeFirebase();
  const [summary, setSummary] = useState<DailyKpiSummaryOutput | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch real data for AI analysis
  const salesQuery = useMemo(() => db ? query(collection(db, 'sales'), limit(20)) : null, [db]);
  const inventoryQuery = useMemo(() => db ? query(collection(db, 'inventory'), limit(20)) : null, [db]);

  const { data: salesData } = useCollection(salesQuery);
  const { data: inventoryData } = useCollection(inventoryQuery);

  useEffect(() => {
    let isMounted = true;
    
    async function loadSummary() {
      // Don't run flow if data is still initializing
      if (!db || salesData === null || inventoryData === null) return;

      try {
        const result = await dailyKpiSummary({
          currentDate: new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          }),
          salesData: (salesData || []).map(s => ({
            product: s.description || 'Unknown Product',
            quantity: 1,
            price: Number(s.amount) || 0,
            timestamp: s.timestamp || new Date().toISOString()
          })),
          inventoryData: (inventoryData || []).map(i => ({
            product: i.name || 'Unknown Item',
            stockLevel: Number(i.quantity) || 0,
            lastUpdated: i.lastUpdated || new Date().toISOString()
          })),
        });
        
        if (isMounted) {
          setSummary(result);
        }
      } catch (error) {
        console.error('Failed to load KPI summary', error);
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }
    
    loadSummary();
    
    return () => {
      isMounted = false;
    };
  }, [db, salesData, inventoryData]);

  if (loading) {
    return (
      <Card className="glass-panel overflow-hidden border-none shadow-xl">
        <CardContent className="p-8 space-y-4">
          <div className="flex items-center gap-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-4 rounded-full" />
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      <Card className="glass-panel overflow-hidden border-none shadow-2xl relative bg-white/60 dark:bg-black/40 backdrop-blur-2xl">
        <div className="absolute top-0 right-0 p-6 opacity-40">
          <Sparkles className="text-primary w-8 h-8 animate-pulse" />
        </div>
        <CardContent className="p-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Sparkles className="text-primary w-5 h-5" />
            </div>
            <h2 className="text-2xl font-headline font-bold text-accent">
              {summary?.greeting || 'System Ready'}
            </h2>
          </div>
          
          <p className="text-lg text-muted-foreground leading-relaxed mb-8 font-medium">
            {summary?.summary}
          </p>
          
          {summary?.actionableInsights && summary.actionableInsights.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-primary/10">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary/60" />
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Actionable Insights</h3>
              </div>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {summary.actionableInsights.map((insight, idx) => (
                  <motion.li 
                    key={idx} 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex items-center gap-3 text-sm bg-primary/5 hover:bg-primary/10 p-4 rounded-2xl border border-primary/10 transition-colors group"
                  >
                    <div className="w-2 h-2 rounded-full bg-primary group-hover:scale-125 transition-transform" />
                    <span className="font-medium">{insight}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};
