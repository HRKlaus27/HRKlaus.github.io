
'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GlobalSphere } from '@/components/GlobalSphere';
import { CodeRainBackground } from '@/components/CodeRainBackground';
import { ShieldCheck, Globe } from 'lucide-react';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export const AuthLoadingScreen = () => {
  const [progress, setProgress] = useState(0);
  const [messageIndex, setMessageIndex] = useState(0);
  
  const heroBg = PlaceHolderImages.find(img => img.id === 'cyber-ai-robot');

  const messages = [
    "Synchronizing Identity Protocol...",
    "Establishing Secure Neural Link...",
    "Loading System Assets...",
    "Initializing Command Center...",
    "Finalizing Secure Connection..."
  ];

  useEffect(() => {
    const duration = 3500;
    const interval = 35; 
    const step = 100 / (duration / interval);

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) return 100;
        return prev + step;
      });
    }, interval);

    const msgTimer = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    }, 700);

    return () => {
      clearInterval(timer);
      clearInterval(msgTimer);
    };
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-6 overflow-hidden"
    >
      {/* Cyber Background Layer - Neural AI Robot */}
      <div className="absolute inset-0 z-0">
        <Image 
          src={heroBg?.imageUrl || "https://picsum.photos/seed/cyber-ai-robot/1920/1080"}
          alt="Neural Backdrop"
          fill
          className="object-cover opacity-50 blur-xl scale-110"
          priority
          data-ai-hint="cybernetic humanoid"
        />
        <div className="absolute inset-0 bg-black/70" />
      </div>

      {/* Cyber Code Overlay */}
      <div className="absolute inset-0 z-[1] opacity-40">
        <CodeRainBackground color="#00ffff" speed={1.2} opacity={1} />
      </div>

      {/* Central Spinning Globe */}
      <div className="absolute inset-0 z-[2] flex items-center justify-center opacity-70">
        <div className="w-[600px] h-[600px] md:w-[800px] md:h-[800px] relative">
          <GlobalSphere />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(177,134,232,0.2),transparent_70%)] pointer-events-none" />
        </div>
      </div>

      {/* Content Overlay */}
      <div className="relative z-[3] w-full max-w-md flex flex-col items-center gap-12">
        <div className="space-y-8 w-full text-center">
          <div className="space-y-4">
            <h2 className="text-4xl font-headline font-bold text-white tracking-tighter drop-shadow-[0_0_20px_rgba(177,134,232,0.6)] uppercase">
              PROJECT SKYnet <span className="text-primary">Core</span>
            </h2>
            <AnimatePresence mode="wait">
              <motion.p
                key={messageIndex}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-xs uppercase tracking-[0.5em] font-bold text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]"
              >
                {messages[messageIndex]}
              </motion.p>
            </AnimatePresence>
          </div>

          {/* Progress Bar Container */}
          <div className="space-y-4 pt-10">
             <div className="flex justify-between items-center px-1">
                <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">System Boot Sequence</span>
                <span className="text-[10px] font-bold text-primary uppercase tracking-widest">{Math.round(progress)}%</span>
             </div>
             <div className="relative h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/10 backdrop-blur-md">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-cyan-500 to-primary shadow-[0_0_20px_rgba(177,134,232,0.8)]"
                />
             </div>
          </div>

          {/* System Stats Overlay */}
          <div className="grid grid-cols-2 gap-4 pt-10">
            <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-[32px] p-6 backdrop-blur-2xl">
              <ShieldCheck className="w-6 h-6 text-cyan-400" />
              <div className="text-left">
                <p className="text-[10px] uppercase font-bold text-white/40 tracking-wider">Security</p>
                <p className="text-sm font-bold text-white">ENCRYPTED</p>
              </div>
            </div>
            <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-[32px] p-6 backdrop-blur-2xl">
              <Globe className="w-6 h-6 text-primary" />
              <div className="text-left">
                <p className="text-[10px] uppercase font-bold text-white/40 tracking-wider">Protocol</p>
                <p className="text-sm font-bold text-white">V4.2.0</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
