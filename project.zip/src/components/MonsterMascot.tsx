
'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { motion } from 'framer-motion';

interface MonsterMascotProps {
  isCoveringEyes?: boolean;
  isWaving?: boolean;
  isExiting?: boolean;
}

export const MonsterMascot: React.FC<MonsterMascotProps> = ({
  isCoveringEyes = false,
  isWaving = false,
  isExiting = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const monsterRef = useRef<THREE.Group | null>(null);
  const leftEyeRef = useRef<THREE.Group | null>(null);
  const rightEyeRef = useRef<THREE.Group | null>(null);
  const leftHandRef = useRef<THREE.Mesh | null>(null);
  const rightHandRef = useRef<THREE.Mesh | null>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    camera.position.z = 8;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
    mainLight.position.set(5, 5, 5);
    scene.add(mainLight);

    const rimLight = new THREE.PointLight(0xffffff, 0.5);
    rimLight.position.set(-5, -2, -2);
    scene.add(rimLight);

    // Monster Group
    const monster = new THREE.Group();
    monsterRef.current = monster;

    // Body (Softer clay-like material)
    const bodyGeometry = new THREE.SphereGeometry(1.6, 64, 64);
    const bodyMaterial = new THREE.MeshPhongMaterial({ 
      color: 0xAB86E8,
      shininess: 5,
      flatShading: false
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    monster.add(body);

    // Eyes
    const createEye = () => {
      const eyeGroup = new THREE.Group();
      
      const whiteGeo = new THREE.SphereGeometry(0.48, 32, 32);
      const whiteMat = new THREE.MeshPhongMaterial({ color: 0xffffff, shininess: 30 });
      const white = new THREE.Mesh(whiteGeo, whiteMat);
      eyeGroup.add(white);

      const pupilGeo = new THREE.SphereGeometry(0.2, 32, 32);
      const pupilMat = new THREE.MeshPhongMaterial({ color: 0x111111 });
      const pupil = new THREE.Mesh(pupilGeo, pupilMat);
      pupil.position.z = 0.42;
      eyeGroup.add(pupil);
      
      return eyeGroup;
    };

    const leftEye = createEye();
    leftEye.position.set(-0.75, 0.5, 1.2);
    leftEyeRef.current = leftEye;
    monster.add(leftEye);

    const rightEye = createEye();
    rightEye.position.set(0.75, 0.5, 1.2);
    rightEyeRef.current = rightEye;
    monster.add(rightEye);

    // Mouth
    const mouthGeo = new THREE.TorusGeometry(0.3, 0.05, 16, 100, Math.PI);
    const mouthMat = new THREE.MeshPhongMaterial({ color: 0x222222 });
    const mouth = new THREE.Mesh(mouthGeo, mouthMat);
    mouth.position.set(0, -0.4, 1.4);
    mouth.rotation.x = Math.PI;
    monster.add(mouth);

    // Hands
    const handGeo = new THREE.SphereGeometry(0.35, 32, 32);
    const handMat = new THREE.MeshPhongMaterial({ color: 0xAB86E8 });
    
    const leftHand = new THREE.Mesh(handGeo, handMat);
    leftHand.position.set(-2.2, -0.2, 0.5);
    leftHandRef.current = leftHand;
    monster.add(leftHand);

    const rightHand = new THREE.Mesh(handGeo, handMat);
    rightHand.position.set(2.2, -0.2, 0.5);
    rightHandRef.current = rightHand;
    monster.add(rightHand);

    scene.add(monster);

    // Animation Loop
    let frameId: number;
    const startTime = Date.now();

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const time = (Date.now() - startTime) * 0.001;

      if (monsterRef.current) {
        // Natural idle floating
        monsterRef.current.position.y = Math.sin(time * 1.5) * 0.15;
        
        // Track mouse rotation
        const targetRotY = mouseRef.current.x * 0.35;
        const targetRotX = mouseRef.current.y * -0.2;
        monsterRef.current.rotation.y += (targetRotY - monsterRef.current.rotation.y) * 0.1;
        monsterRef.current.rotation.x += (targetRotX - monsterRef.current.rotation.x) * 0.1;
      }

      if (leftEyeRef.current && rightEyeRef.current) {
        // Pupil tracking
        const pupilX = mouseRef.current.x * 0.12;
        const pupilY = mouseRef.current.y * -0.12;
        
        const leftPupil = leftEyeRef.current.children[1];
        const rightPupil = rightEyeRef.current.children[1];
        
        leftPupil.position.x += (pupilX - leftPupil.position.x) * 0.15;
        leftPupil.position.y += (pupilY - leftPupil.position.y) * 0.15;
        rightPupil.position.x += (pupilX - rightPupil.position.x) * 0.15;
        rightPupil.position.y += (pupilY - rightPupil.position.y) * 0.15;
      }

      // Interaction Logic
      if (isCoveringEyes && leftHandRef.current && rightHandRef.current) {
        // Move hands over eyes
        leftHandRef.current.position.lerp(new THREE.Vector3(-0.75, 0.6, 1.8), 0.2);
        rightHandRef.current.position.lerp(new THREE.Vector3(0.75, 0.6, 1.8), 0.2);
      } else if (isWaving && rightHandRef.current && leftHandRef.current) {
        // Wave right hand
        leftHandRef.current.position.lerp(new THREE.Vector3(-2.2, -0.2, 0.5), 0.1);
        rightHandRef.current.position.set(2.1, 0.5 + Math.sin(time * 8) * 0.3, 0.5);
      } else if (leftHandRef.current && rightHandRef.current) {
        // Natural idle hand movement
        leftHandRef.current.position.lerp(new THREE.Vector3(-2.2, -0.2 + Math.sin(time * 1.5 + 1) * 0.1, 0.5), 0.1);
        rightHandRef.current.position.lerp(new THREE.Vector3(2.2, -0.2 + Math.sin(time * 1.5) * 0.1, 0.5), 0.1);
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleMouseMove = (event: MouseEvent) => {
      mouseRef.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.y = (event.clientY / window.innerHeight) * 2 - 1;
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('mousemove', handleMouseMove);
      renderer.dispose();
      if (containerRef.current) containerRef.current.innerHTML = '';
    };
  }, [isCoveringEyes, isWaving]);

  return (
    <motion.div
      animate={isExiting ? { y: -200, rotate: 20, opacity: 0 } : { y: 0, rotate: 0, opacity: 1 }}
      transition={{ type: 'spring', damping: 15, stiffness: 80 }}
      className="w-full h-full flex items-center justify-center"
    >
      <div ref={containerRef} className="w-full h-full" />
    </motion.div>
  );
};
